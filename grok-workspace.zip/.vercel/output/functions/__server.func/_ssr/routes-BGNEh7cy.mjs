import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as Plus, g as ArrowRight, n as UserRound, o as Share2, u as ImagePlus } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as useCurrentUserState, i as useCurrentUser, t as Button } from "./button-DIbJSJWX.mjs";
import { n as Label, t as Input } from "./label-B1gzM7dO.mjs";
import { c as createPack, l as deletePack, m as listPacks, o as Skeleton, t as AppShell } from "./api-mfaWCtwL.mjs";
import { a as DialogDescription, c as DialogTitle, i as DialogContent, o as DialogFooter, r as Dialog, s as DialogHeader } from "./types-NQi8Ka8c.mjs";
import { t as useDraftStore } from "./draft-store-CzA8EYoi.mjs";
import { t as PackCard } from "./pack-card-Dso3xp-Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BGNEh7cy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CreatePackDialog({ open, onOpenChange }) {
	const navigate = useNavigate();
	const user = useCurrentUser();
	const setMeta = useDraftStore((s) => s.setMeta);
	const [name, setName] = (0, import_react.useState)("");
	const [artist, setArtist] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function submit(e) {
		e.preventDefault();
		const packName = name.trim();
		const packArtist = artist.trim();
		if (!packName || !packArtist) {
			toast.error("Isi nama pack dan nama artis");
			return;
		}
		setBusy(true);
		try {
			if (user) {
				const created = await createPack({ data: {
					name: packName,
					artist: packArtist
				} });
				onOpenChange(false);
				setName("");
				setArtist("");
				await navigate({
					to: "/pack/$packId",
					params: { packId: created.id }
				});
			} else {
				setMeta(packName, packArtist);
				onOpenChange(false);
				await navigate({
					to: "/pack/$packId",
					params: { packId: "draft" }
				});
			}
		} catch (err) {
			const message = err instanceof Error ? err.message : "Gagal membuat pack";
			if (message === "Unauthorized") {
				setMeta(packName, packArtist);
				await navigate({
					to: "/login",
					search: { next: "/pack/draft" }
				});
				return;
			}
			toast.error(message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "grid gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Pack stiker baru" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Mulai dari nama pack dan artisnya. Setelah itu kamu bisa unggah gambar lewat tombol plus." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "pack-name",
						children: "Nama pack"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "pack-name",
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "Misal: Mood Hari Ini",
						maxLength: 128,
						autoFocus: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "pack-artist",
						children: "Nama artis"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "pack-artist",
						value: artist,
						onChange: (e) => setArtist(e.target.value),
						placeholder: "Nama kamu atau studio",
						maxLength: 128
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					onClick: () => onOpenChange(false),
					children: "Batal"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: busy,
					children: busy ? "Membuat…" : "Lanjut unggah"
				})] })
			]
		}) })
	});
}
function Home() {
	const { user, isPending } = useCurrentUserState();
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			size: "sm",
			onClick: () => setOpen(true),
			children: "Pack baru"
		}),
		children: [isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeSkeleton, {}) : user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, { onCreate: () => setOpen(true) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landing, { onCreate: () => setOpen(true) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreatePackDialog, {
			open,
			onOpenChange: setOpen
		})]
	});
}
function HomeSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-6xl px-4 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-64" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid grid-cols-2 gap-3 md:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "aspect-square rounded-xl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "aspect-square rounded-xl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "aspect-square rounded-xl" })
			]
		})]
	});
}
function Studio({ onCreate }) {
	const queryClient = useQueryClient();
	const packs = useQuery({
		queryKey: ["packs"],
		queryFn: () => listPacks()
	});
	const remove = useMutation({
		mutationFn: (id) => deletePack({ data: id }),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["packs"] });
			toast.success("Pack dihapus");
		},
		onError: (err) => toast.error(err instanceof Error ? err.message : "Gagal menghapus")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-6xl px-4 py-8 sm:py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase",
					children: "Studio"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-4xl font-medium tracking-tight",
					children: "Pack kamu"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm text-muted-foreground",
					children: "Buka pack untuk menambah stiker, simpan ke profil, lalu kirim ke WhatsApp."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "outline",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/profile",
					children: "Lihat profil"
				})
			})]
		}), packs.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "aspect-[3/4] rounded-xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "aspect-[3/4] rounded-xl" })]
		}) : packs.data && packs.data.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4",
			children: [packs.data.map((pack) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackCard, {
				pack,
				onDelete: (id) => {
					if (confirm("Hapus pack ini beserta stikernya?")) remove.mutate(id);
				}
			}, pack.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onCreate,
				className: "flex min-h-56 flex-col items-center justify-center gap-2 rounded-xl bg-card text-muted-foreground shadow-(--shadow-border) transition-[box-shadow] duration-150 hover:shadow-(--shadow-border-hover)",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-12 place-items-center rounded-full bg-primary text-primary-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-6" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm",
					children: "Pack baru"
				})]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-10 rounded-xl bg-card px-6 py-14 text-center shadow-(--shadow-border)",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl",
					children: "Studio masih kosong"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-2 max-w-md text-sm text-muted-foreground",
					children: "Buat pack, tulis nama artis, lalu tekan plus untuk unggah gambar."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					className: "mt-6",
					onClick: onCreate,
					children: "Buat pack pertama"
				})
			]
		})]
	});
}
function Landing({ onCreate }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "paper-grid relative overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid w-full max-w-6xl gap-10 px-4 py-12 lg:grid-cols-[1.1fr_0.9fr] lg:items-center lg:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rise-in text-xs font-medium tracking-[0.18em] text-primary uppercase",
					children: "Studio stiker WhatsApp"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "rise-in-2 mt-3 max-w-xl font-display text-4xl font-medium tracking-tight sm:text-6xl",
					children: "Pack stiker, dari gambar biasa."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rise-in-3 mt-4 max-w-lg text-base text-muted-foreground sm:text-lg",
					children: "Tulis nama pack dan artisnya, unggah foto, Stikera merapikan jadi stiker 512×512 siap dikirim ke WhatsApp."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-col gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						size: "lg",
						onClick: onCreate,
						children: ["Mulai pack baru", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							search: { next: "/" },
							children: "Masuk / daftar"
						})
					})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickerStage, {})]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto grid w-full max-w-6xl gap-3 px-4 py-12 sm:grid-cols-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-5" }),
				n: "01",
				title: "Nama pack & artis",
				body: "Setiap pack punya judul dan penerbit, seperti pack WhatsApp resmi."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-5" }),
				n: "02",
				title: "Unggah, rapikan",
				body: "Tombol plus menerima banyak gambar. Latar dibersihkan, garis tepi ditambah."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-5" }),
				n: "03",
				title: "Simpan & kirim",
				body: "Simpan ke profil, unduh ZIP, atau bagikan file WebP ke chat WhatsApp."
			})
		]
	})] });
}
function Step({ n, title, body, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-xl bg-card p-5 shadow-(--shadow-border)",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-10 place-items-center rounded-md bg-secondary text-secondary-foreground",
					children: icon
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-sm text-muted-foreground",
					children: n
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-5 font-display text-xl font-medium",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: body
			})
		]
	});
}
function StickerStage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto h-80 w-full max-w-md sm:h-96",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-8 rounded-[2rem] bg-card shadow-(--shadow-lift)" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticker-checker rise-in absolute top-8 left-6 size-28 -rotate-6 rounded-2xl shadow-(--shadow-lift) sm:size-32",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 64 64",
					className: "size-full p-4 text-primary",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "32",
						cy: "32",
						r: "18",
						fill: "currentColor"
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticker-checker rise-in-2 absolute top-4 right-8 size-28 rotate-3 rounded-2xl shadow-(--shadow-lift) sm:size-32",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 64 64",
					className: "size-full p-4 text-primary",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M32 12l6 14h14l-11 9 4 15-13-9-13 9 4-15-11-9h14z",
						fill: "currentColor"
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticker-checker rise-in-3 absolute bottom-10 left-16 size-28 -rotate-2 rounded-2xl shadow-(--shadow-lift) sm:size-32",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 64 64",
					className: "size-full p-4 text-primary",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M32 14c8 8 18 12 18 24a18 18 0 1 1-36 0c0-12 10-16 18-24z",
						fill: "currentColor"
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticker-checker absolute right-10 bottom-8 size-28 rotate-6 rounded-2xl shadow-(--shadow-lift) sm:size-32",
				style: { animation: "rise-in 400ms var(--ease-smooth-out) 200ms both" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 64 64",
					className: "size-full p-4 text-primary",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "16",
						y: "16",
						width: "32",
						height: "32",
						rx: "10",
						fill: "currentColor"
					})
				})
			})
		]
	});
}
//#endregion
export { Home as component };
