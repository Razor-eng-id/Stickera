import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-D8Cj4eP7.mjs";
import { i as signOut } from "./client-B40BzJxt.mjs";
import { l as LogOut, n as UserRound } from "../_libs/lucide-react.mjs";
import { a as useCurrentUserState, n as Logo, r as cn, t as Button } from "./button-DIbJSJWX.mjs";
import { a as Root2, i as Portal2, n as Item2, o as Separator2, r as Label2, s as Trigger, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-mfaWCtwL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 min-w-44 overflow-hidden rounded-lg bg-card p-1 text-card-foreground shadow-(--shadow-lift)", className),
	...props
}) }));
DropdownMenuContent.displayName = Content2.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
	ref,
	className: cn("relative flex cursor-pointer select-none items-center gap-2 rounded-md px-3 py-2 text-sm outline-none transition-colors focus:bg-muted data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props
}));
DropdownMenuItem.displayName = Item2.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-border", className),
	...props
}));
DropdownMenuSeparator.displayName = Separator2.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label2, {
	ref,
	className: cn("px-3 py-2 text-xs font-medium text-muted-foreground", className),
	...props
}));
DropdownMenuLabel.displayName = Label2.displayName;
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-muted", className),
		...props
	});
}
function AccountMenu({ next }) {
	const { user, isPending } = useCurrentUserState();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "size-10 rounded-full" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		asChild: true,
		variant: "outline",
		size: "sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/login",
			search: { next: next ?? "/" },
			children: "Masuk"
		})
	});
	const label = user.displayName ?? user.primaryEmail ?? "Akun";
	const initial = label.charAt(0).toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "flex size-10 items-center justify-center overflow-hidden rounded-full bg-secondary text-sm font-medium text-secondary-foreground shadow-(--shadow-border) focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50",
			"aria-label": "Menu akun",
			children: user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "size-full object-cover"
			}) : initial
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
		align: "end",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuLabel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "truncate text-foreground",
				children: label
			}), user.primaryEmail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "truncate font-normal",
				children: user.primaryEmail
			}) : null] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/profile",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-4" }), "Profil"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				disabled: signingOut,
				onSelect: () => {
					setSigningOut(true);
					signOut("/").catch(() => setSigningOut(false));
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), signingOut ? "Keluar…" : "Keluar"]
			})
		]
	})] });
}
function AppShell({ children, next, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-40 border-b border-border/80 bg-background/90 backdrop-blur-sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-3 px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [action, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountMenu, { next })]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex-1",
			children
		})]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var listPacks = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("7950e6072ab716895021fc329b6c6ecd826acf25fc772513c7d9862b9953e4b0"));
var getPack = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((id) => id).handler(createSsrRpc("3a3b11ae38ba89321405094045e59cdf081946c7684a7e200cc49b5e5bbf52fa"));
var getPublicPack = createServerFn({ method: "GET" }).validator((shareId) => shareId).handler(createSsrRpc("5ab0bc3ae481af3bfe2d5dfe546616230a45374095d314022fbc40cf8b12e08e"));
var createPack = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const name = input.name.trim().slice(0, 128);
	const artist = input.artist.trim().slice(0, 128);
	if (!name) throw new Error("Nama pack wajib diisi");
	if (!artist) throw new Error("Nama artis wajib diisi");
	return {
		name,
		artist
	};
}).handler(createSsrRpc("6f3a46375460f2bdcbbf1e4c104d91586fa41d21474829f7bdb1739bd1714890"));
var updatePackMeta = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("4f040739524aeae7f4522974a2c9da508ab5b5caa1fbbdcd5846398358d8fcc2"));
var savePackToProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(createSsrRpc("1cc51caa24f1373f42e200c38fba098c8dde860900dd72595468ef31111d08ee"));
var deletePack = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(createSsrRpc("14f3ccce267d6602f9c1459a0df0147950d5b6d2f9c68a33109152d8b204f20b"));
var addStickers = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("a3e86de6fa1e5d8c11508c99ff031e5252e5b2dc4bcdbad8693839b64faadc1c"));
var deleteSticker = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("1f027979c4e6aa30249625619cb9f1d9ab98479931f22e3f08ceedd7ae5595eb"));
var importDraftPack = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("70790bc0279fe6e2da584222e4f3f37b802aeaa39d5a40535b7dc12df2546fc6"));
//#endregion
export { DropdownMenuTrigger as a, createPack as c, getPack as d, getPublicPack as f, updatePackMeta as g, savePackToProfile as h, DropdownMenuItem as i, deletePack as l, listPacks as m, DropdownMenu as n, Skeleton as o, importDraftPack as p, DropdownMenuContent as r, addStickers as s, AppShell as t, deleteSticker as u };
