import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link, v as Navigate, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as newId } from "./ids-CcjM0-Bt.mjs";
import { a as Trash2, c as Plus, h as Bookmark, r as Upload, s as Send } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as Route$2 } from "./router-ODedQPIH.mjs";
import { a as useCurrentUserState, r as cn, t as Button } from "./button-DIbJSJWX.mjs";
import { n as Label, t as Input } from "./label-B1gzM7dO.mjs";
import { d as getPack, g as updatePackMeta, h as savePackToProfile, o as Skeleton, p as importDraftPack, s as addStickers, t as AppShell, u as deleteSticker } from "./api-mfaWCtwL.mjs";
import { l as MAX_STICKER_BYTES, n as DRAFT_PACK_ID, t as DEFAULT_PROCESS } from "./types-NQi8Ka8c.mjs";
import { t as useDraftStore } from "./draft-store-CzA8EYoi.mjs";
import { t as Badge } from "./badge-CnPWTdT1.mjs";
import { i as processSticker, n as SendDialog, r as makeTrayIcon, t as ChatPreview } from "./send-dialog-KxyITUak.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pack._packId-DIF_ctLK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function formatBytes(n) {
	if (n < 1024) return `${n} B`;
	return `${Math.round(n / 1024)} KB`;
}
function StickerEditor({ pack, onAdd, onRemove, disabled }) {
	const inputRef = (0, import_react.useRef)(null);
	const [options, setOptions] = (0, import_react.useState)(DEFAULT_PROCESS);
	const [processing, setProcessing] = (0, import_react.useState)(false);
	const [dragOver, setDragOver] = (0, import_react.useState)(false);
	const remaining = 30 - pack.stickers.length;
	async function handleFiles(files) {
		const list = Array.from(files).filter((f) => f.type.startsWith("image/"));
		if (list.length === 0) {
			toast.error("Pilih file gambar");
			return;
		}
		if (remaining <= 0) {
			toast.error("Pack sudah penuh (30 stiker)");
			return;
		}
		const take = list.slice(0, remaining);
		if (take.length < list.length) toast.message(`Hanya ${take.length} gambar yang ditambah (batas 30)`);
		setProcessing(true);
		try {
			const next = [];
			let gifCount = 0;
			for (const file of take) {
				const processed = await processSticker(file, options);
				if (processed.wasGif) gifCount += 1;
				next.push({
					id: newId("stk"),
					packId: pack.id,
					imageWebp: processed.dataUrl,
					emojis: "😀",
					sortOrder: pack.stickers.length + next.length,
					byteSize: processed.bytes,
					createdAt: (/* @__PURE__ */ new Date()).toISOString()
				});
			}
			await onAdd(next);
			if (gifCount) toast.message("GIF dipakai sebagai stiker statis (frame pertama).");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Gagal memproses gambar");
		} finally {
			setProcessing(false);
			if (inputRef.current) inputRef.current.value = "";
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleChip, {
						label: "Hapus latar",
						active: options.removeBackground,
						onClick: () => setOptions((o) => ({
							...o,
							removeBackground: !o.removeBackground
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleChip, {
						label: "Garis tepi",
						active: options.outline,
						onClick: () => setOptions((o) => ({
							...o,
							outline: !o.outline
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleChip, {
						label: options.fit === "contain" ? "Muat utuh" : "Potong isi",
						active: true,
						onClick: () => setOptions((o) => ({
							...o,
							fit: o.fit === "contain" ? "cover" : "contain"
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-auto text-xs tabular-nums text-muted-foreground",
						children: [
							pack.stickers.length,
							"/",
							30
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				accept: "image/*",
				multiple: true,
				className: "sr-only",
				onChange: (e) => {
					if (e.target.files) handleFiles(e.target.files);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				onDragOver: (e) => {
					e.preventDefault();
					setDragOver(true);
				},
				onDragLeave: () => setDragOver(false),
				onDrop: (e) => {
					e.preventDefault();
					setDragOver(false);
					if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files);
				},
				className: cn("grid grid-cols-3 gap-2 sm:grid-cols-4 md:grid-cols-5", dragOver && "rounded-xl ring-2 ring-ring/40"),
				children: [pack.stickers.map((sticker) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickerTile, {
					sticker,
					onRemove: () => void onRemove(sticker.id),
					disabled: disabled || processing
				}, sticker.id)), remaining > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: disabled || processing,
					onClick: () => inputRef.current?.click(),
					className: "sticker-checker relative flex aspect-square flex-col items-center justify-center gap-2 rounded-lg bg-card text-muted-foreground shadow-(--shadow-border) transition-[box-shadow,transform] duration-150 hover:shadow-(--shadow-border-hover) active:scale-[0.96] disabled:opacity-60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-12 place-items-center rounded-full bg-primary text-primary-foreground",
						children: processing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-5 animate-pulse" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "px-2 text-center text-xs",
						children: processing ? "Memproses…" : "Unggah gambar"
					})]
				}) : null]
			})
		]
	});
}
function ToggleChip({ label, active, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-9 rounded-full px-3 text-xs font-medium transition-colors duration-150", active ? "bg-secondary text-secondary-foreground" : "bg-muted text-muted-foreground"),
		children: label
	});
}
function StickerTile({ sticker, onRemove, disabled }) {
	const over = sticker.byteSize > MAX_STICKER_BYTES;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "group relative aspect-square overflow-hidden rounded-lg bg-card shadow-(--shadow-border)",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticker-checker absolute inset-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: sticker.imageWebp,
					alt: "",
					className: "size-full object-contain p-1"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: over ? "default" : "muted",
				className: cn("absolute left-1.5 top-1.5 tabular-nums", over && "bg-destructive text-destructive-foreground"),
				children: formatBytes(sticker.byteSize)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled,
				onClick: onRemove,
				"aria-label": "Hapus stiker",
				className: "absolute right-1.5 top-1.5 grid size-9 place-items-center rounded-full bg-card/95 text-foreground opacity-100 shadow-(--shadow-border) transition-opacity sm:opacity-0 sm:group-hover:opacity-100",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
			})
		]
	});
}
function PackEditorPage() {
	const { packId } = Route$2.useParams();
	const isDraft = packId === DRAFT_PACK_ID;
	const { user, isPending } = useCurrentUserState();
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const draft = useDraftStore((s) => s.pack);
	const [sendOpen, setSendOpen] = (0, import_react.useState)(false);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [artist, setArtist] = (0, import_react.useState)("");
	const query = useQuery({
		queryKey: ["pack", packId],
		queryFn: () => getPack({ data: packId }),
		enabled: !isDraft && !!user
	});
	const pack = isDraft ? draft : query.data ?? null;
	(0, import_react.useEffect)(() => {
		if (!pack) return;
		setName(pack.name);
		setArtist(pack.artist);
	}, [pack]);
	const localPack = (0, import_react.useMemo)(() => {
		if (!pack) return null;
		return {
			...pack,
			name: name || pack.name,
			artist: artist || pack.artist
		};
	}, [
		pack,
		name,
		artist
	]);
	async function persistMeta(next) {
		if (isDraft) {
			useDraftStore.getState().setMeta(next.name, next.artist);
			if (next.trayImage) useDraftStore.getState().setTray(next.trayImage);
			return;
		}
		await updatePackMeta({ data: {
			id: next.id,
			name: next.name,
			artist: next.artist,
			trayImage: next.trayImage
		} });
		await queryClient.invalidateQueries({ queryKey: ["pack", packId] });
		await queryClient.invalidateQueries({ queryKey: ["packs"] });
	}
	async function onAdd(stickers) {
		if (isDraft) {
			useDraftStore.getState().addStickers(stickers);
			const current = useDraftStore.getState().pack;
			if (current?.stickers[0] && !current.trayImage) try {
				const tray = await makeTrayIcon(current.stickers[0].imageWebp);
				useDraftStore.getState().setTray(tray);
			} catch {}
			return;
		}
		if (!user) {
			toast.error("Masuk dulu untuk menyimpan stiker");
			return;
		}
		for (const s of stickers) await addStickers({ data: {
			packId,
			stickers: [{
				imageWebp: s.imageWebp,
				emojis: s.emojis,
				byteSize: s.byteSize
			}]
		} });
		await queryClient.invalidateQueries({ queryKey: ["pack", packId] });
		await queryClient.invalidateQueries({ queryKey: ["packs"] });
	}
	async function onRemove(id) {
		if (isDraft) {
			useDraftStore.getState().removeSticker(id);
			return;
		}
		await deleteSticker({ data: {
			packId,
			stickerId: id
		} });
		await queryClient.invalidateQueries({ queryKey: ["pack", packId] });
		await queryClient.invalidateQueries({ queryKey: ["packs"] });
	}
	async function onSaveProfile() {
		if (!localPack) return;
		if (localPack.stickers.length === 0) {
			toast.error("Unggah minimal satu stiker dulu");
			return;
		}
		if (!user) {
			useDraftStore.getState().setMeta(name, artist);
			await navigate({
				to: "/login",
				search: { next: "/pack/draft" }
			});
			return;
		}
		setSaving(true);
		try {
			if (isDraft) {
				let tray = localPack.trayImage;
				if (!tray && localPack.stickers[0]) tray = await makeTrayIcon(localPack.stickers[0].imageWebp);
				const created = await importDraftPack({ data: {
					name: name.trim() || localPack.name,
					artist: artist.trim() || localPack.artist,
					trayImage: tray,
					stickers: localPack.stickers.map((s) => ({
						imageWebp: s.imageWebp,
						emojis: s.emojis,
						byteSize: s.byteSize
					}))
				} });
				useDraftStore.getState().clear();
				toast.success("Pack disimpan ke profil");
				await queryClient.invalidateQueries({ queryKey: ["packs"] });
				await navigate({
					to: "/pack/$packId",
					params: { packId: created.id }
				});
				return;
			}
			await persistMeta({
				...localPack,
				name: name.trim(),
				artist: artist.trim()
			});
			await savePackToProfile({ data: packId });
			toast.success("Pack disimpan ke profil");
			await queryClient.invalidateQueries({ queryKey: ["pack", packId] });
			await queryClient.invalidateQueries({ queryKey: ["packs"] });
		} catch (err) {
			const message = err instanceof Error ? err.message : "Gagal menyimpan";
			if (message === "Unauthorized") {
				await navigate({
					to: "/login",
					search: { next: `/pack/${packId}` }
				});
				return;
			}
			toast.error(message);
		} finally {
			setSaving(false);
		}
	}
	if (!isDraft && !isPending && !user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, {
		to: "/login",
		search: { next: `/pack/${packId}` }
	});
	if (isPending && !isDraft) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-48" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-6 h-64 w-full rounded-xl" })]
	}) });
	if (!isDraft && !query.isLoading && !pack) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-lg px-4 py-20 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Pack tidak ditemukan"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Pack ini bukan milik akun kamu, atau sudah dihapus."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: "Kembali ke studio"
				})
			})
		]
	}) });
	if (isDraft && !draft) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-lg px-4 py-20 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Belum ada draf"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Buat pack baru untuk mulai mengunggah stiker."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: "Buat pack"
				})
			})
		]
	}) });
	if (!localPack) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64 w-full rounded-xl" })
	}) });
	const saved = !isDraft && localPack.status === "saved";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		next: `/pack/${packId}`,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hidden items-center gap-2 sm:flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "outline",
				size: "sm",
				onClick: () => setSendOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" }), "Kirim"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				size: "sm",
				onClick: () => void onSaveProfile(),
				disabled: saving,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" }), saving ? "Menyimpan…" : saved ? "Tersimpan" : "Simpan ke profil"]
			})]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto grid w-full max-w-6xl gap-8 px-4 py-6 pb-24 lg:grid-cols-[minmax(0,1fr)_280px] lg:py-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase",
						children: isDraft ? "Draf lokal" : saved ? "Pack tersimpan" : "Draf"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "name",
								children: "Nama pack"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "name",
								value: name,
								onChange: (e) => setName(e.target.value),
								onBlur: () => void persistMeta({
									...localPack,
									name: name.trim() || localPack.name,
									artist
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "artist",
								children: "Artis"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "artist",
								value: artist,
								onChange: (e) => setArtist(e.target.value),
								onBlur: () => void persistMeta({
									...localPack,
									name,
									artist: artist.trim() || localPack.artist
								})
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickerEditor, {
							pack: localPack,
							onAdd,
							onRemove
						})
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "space-y-4 lg:sticky lg:top-24 lg:self-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatPreview, { pack: localPack }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "WhatsApp butuh 3–30 stiker per pack. Stiker dibuat 512×512 WebP dengan latar transparan."
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky bottom-0 z-30 border-t border-border bg-background/95 px-4 py-3 backdrop-blur-sm sm:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						className: "flex-1",
						onClick: () => setSendOpen(true),
						children: "Kirim"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						className: "flex-1",
						onClick: () => void onSaveProfile(),
						disabled: saving,
						children: saving ? "Menyimpan…" : "Simpan"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SendDialog, {
				pack: localPack,
				open: sendOpen,
				onOpenChange: setSendOpen
			})
		]
	});
}
//#endregion
export { PackEditorPage as component };
