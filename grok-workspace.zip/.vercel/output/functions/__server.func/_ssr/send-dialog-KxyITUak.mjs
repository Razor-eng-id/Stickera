import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { f as Download, m as Check, o as Share2, p as Copy } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Button } from "./button-DIbJSJWX.mjs";
import { a as DialogDescription, c as DialogTitle, i as DialogContent, l as MAX_STICKER_BYTES, r as Dialog, s as DialogHeader } from "./types-NQi8Ka8c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/send-dialog-KxyITUak.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ChatPreview({ pack }) {
	const stickers = pack.stickers.slice(0, 6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-xl bg-chat text-primary-foreground shadow-(--shadow-lift)",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3 border-b border-white/10 px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-8 place-items-center rounded-full bg-primary text-xs font-medium",
				children: pack.artist.slice(0, 1).toUpperCase() || "S"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-sm font-medium",
					children: pack.name || "Pack stiker"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-xs text-white/60",
					children: pack.artist || "Artis"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 px-4 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-w-[85%] rounded-lg rounded-tl-sm bg-chat-bubble px-3 py-2 text-sm text-white/90",
				children: "Kirim pack ini ke chat WhatsApp. Stiker tampil seperti ini."
			}), stickers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-white/50",
				children: "Unggah stiker untuk melihat pratinjau."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap justify-end gap-2",
				children: stickers.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: s.imageWebp,
					alt: "",
					className: "size-16 object-contain drop-shadow-sm"
				}, s.id))
			})]
		})]
	});
}
function dataUrlBytes(dataUrl) {
	const comma = dataUrl.indexOf(",");
	const b64 = comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl;
	return Math.floor(b64.length * 3 / 4);
}
function loadBitmap(file) {
	return createImageBitmap(file);
}
function dist(r1, g1, b1, r2, g2, b2) {
	return Math.abs(r1 - r2) + Math.abs(g1 - g2) + Math.abs(b1 - b2);
}
function hasTransparency(data) {
	for (let i = 3; i < data.length; i += 4) if (data[i] < 250) return true;
	return false;
}
function floodClear(data, width, height, sx, sy, tr, tg, tb, threshold, visited) {
	const stack = [sy * width + sx];
	while (stack.length) {
		const i = stack.pop();
		if (i < 0 || i >= width * height || visited[i]) continue;
		const p = i * 4;
		if (data[p + 3] === 0) {
			visited[i] = 1;
			continue;
		}
		if (dist(data[p], data[p + 1], data[p + 2], tr, tg, tb) > threshold) continue;
		visited[i] = 1;
		data[p + 3] = 0;
		const x = i % width;
		const y = i / width | 0;
		if (x > 0) stack.push(i - 1);
		if (x + 1 < width) stack.push(i + 1);
		if (y > 0) stack.push(i - width);
		if (y + 1 < height) stack.push(i + width);
	}
}
function removeBackground(image) {
	const { data, width, height } = image;
	if (hasTransparency(data)) return;
	const samples = [
		0,
		(width - 1) * 4,
		(height - 1) * width * 4,
		((height - 1) * width + (width - 1)) * 4
	];
	let sr = 0;
	let sg = 0;
	let sb = 0;
	for (const i of samples) {
		sr += data[i];
		sg += data[i + 1];
		sb += data[i + 2];
	}
	sr = sr / 4 | 0;
	sg = sg / 4 | 0;
	sb = sb / 4 | 0;
	const cornersClose = dist(data[0], data[1], data[2], sr, sg, sb) < 80 && dist(data[(width - 1) * 4], data[(width - 1) * 4 + 1], data[(width - 1) * 4 + 2], sr, sg, sb) < 80;
	const brightBg = sr > 220 && sg > 220 && sb > 220;
	if (!cornersClose && !brightBg) return;
	const visited = new Uint8Array(width * height);
	const starts = [
		[0, 0],
		[width - 1, 0],
		[0, height - 1],
		[width - 1, height - 1],
		[width / 2 | 0, 0],
		[width / 2 | 0, height - 1],
		[0, height / 2 | 0],
		[width - 1, height / 2 | 0]
	];
	const threshold = brightBg ? 72 : 54;
	for (const [x, y] of starts) floodClear(data, width, height, x, y, sr, sg, sb, threshold, visited);
	const copy = new Uint8ClampedArray(data);
	for (let y = 1; y < height - 1; y++) for (let x = 1; x < width - 1; x++) {
		const i = (y * width + x) * 4;
		if (copy[i + 3] === 0) continue;
		let empty = 0;
		for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) if (copy[((y + oy) * width + (x + ox)) * 4 + 3] === 0) empty++;
		if (empty >= 3) data[i + 3] = Math.max(0, data[i + 3] - empty * 18);
	}
}
function addOutline(image, radius) {
	const { width, height, data } = image;
	const out = new ImageData(width, height);
	const dest = out.data;
	dest.set(data);
	const opaque = new Uint8Array(width * height);
	for (let i = 0; i < width * height; i++) opaque[i] = data[i * 4 + 3] > 24 ? 1 : 0;
	for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
		const idx = y * width + x;
		if (opaque[idx]) continue;
		let near = false;
		const y0 = Math.max(0, y - radius);
		const y1 = Math.min(height - 1, y + radius);
		const x0 = Math.max(0, x - radius);
		const x1 = Math.min(width - 1, x + radius);
		const r2 = radius * radius;
		for (let ny = y0; ny <= y1 && !near; ny++) for (let nx = x0; nx <= x1; nx++) {
			const dx = nx - x;
			const dy = ny - y;
			if (dx * dx + dy * dy > r2) continue;
			if (opaque[ny * width + nx]) {
				near = true;
				break;
			}
		}
		if (near) {
			const p = idx * 4;
			dest[p] = 255;
			dest[p + 1] = 255;
			dest[p + 2] = 255;
			dest[p + 3] = 255;
		}
	}
	for (let i = 0; i < width * height; i++) {
		if (!opaque[i]) continue;
		const p = i * 4;
		dest[p] = data[p];
		dest[p + 1] = data[p + 1];
		dest[p + 2] = data[p + 2];
		dest[p + 3] = data[p + 3];
	}
	return out;
}
function drawFitted(ctx, bitmap, size, fit, padding) {
	const box = size - padding * 2;
	const bw = bitmap.width;
	const bh = bitmap.height;
	const scale = fit === "cover" ? Math.max(box / bw, box / bh) : Math.min(box / bw, box / bh);
	const dw = bw * scale;
	const dh = bh * scale;
	const dx = (size - dw) / 2;
	const dy = (size - dh) / 2;
	ctx.clearRect(0, 0, size, size);
	ctx.drawImage(bitmap, dx, dy, dw, dh);
}
async function canvasToWebp(canvas, maxBytes) {
	let quality = .84;
	let best = "";
	for (let i = 0; i < 8; i++) {
		const dataUrl = canvas.toDataURL("image/webp", quality);
		const bytes = dataUrlBytes(dataUrl);
		best = dataUrl;
		if (bytes <= maxBytes) return {
			dataUrl,
			bytes,
			wasGif: false
		};
		quality -= .08;
	}
	return {
		dataUrl: best,
		bytes: dataUrlBytes(best),
		wasGif: false
	};
}
async function processSticker(file, options) {
	if (!file.type.startsWith("image/")) throw new Error("File bukan gambar");
	const wasGif = file.type === "image/gif";
	const bitmap = await loadBitmap(file);
	const size = 512;
	const canvas = document.createElement("canvas");
	canvas.width = size;
	canvas.height = size;
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) throw new Error("Canvas tidak tersedia");
	const pad = options.outline ? 18 : options.fit === "contain" ? 8 : 0;
	drawFitted(ctx, bitmap, size, options.fit, pad);
	bitmap.close();
	let image = ctx.getImageData(0, 0, size, size);
	if (options.removeBackground) removeBackground(image);
	if (options.outline) image = addOutline(image, 10);
	ctx.clearRect(0, 0, size, size);
	ctx.putImageData(image, 0, 0);
	const result = await canvasToWebp(canvas, MAX_STICKER_BYTES);
	result.wasGif = wasGif;
	return result;
}
async function makeTrayIcon(stickerDataUrl) {
	const img = await loadImage(stickerDataUrl);
	const canvas = document.createElement("canvas");
	canvas.width = 96;
	canvas.height = 96;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Canvas tidak tersedia");
	ctx.clearRect(0, 0, 96, 96);
	ctx.drawImage(img, 0, 0, 96, 96);
	return canvas.toDataURL("image/png");
}
function loadImage(src) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error("Gagal memuat gambar"));
		img.src = src;
	});
}
function dataUrlToBlob(dataUrl) {
	const [head, body] = dataUrl.split(",", 2);
	const mime = /data:([^;]+)/.exec(head)?.[1] ?? "application/octet-stream";
	const binary = atob(body ?? "");
	const bytes = new Uint8Array(binary.length);
	for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
	return new Blob([bytes], { type: mime });
}
var CRC_TABLE = (() => {
	const table = /* @__PURE__ */ new Uint32Array(256);
	for (let i = 0; i < 256; i++) {
		let c = i;
		for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
		table[i] = c >>> 0;
	}
	return table;
})();
function crc32(buf) {
	let c = 4294967295;
	for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 255] ^ c >>> 8;
	return (c ^ 4294967295) >>> 0;
}
function strBytes(s) {
	return new TextEncoder().encode(s);
}
async function blobToBytes(blob) {
	return new Uint8Array(await blob.arrayBuffer());
}
function u16(n) {
	const b = /* @__PURE__ */ new Uint8Array(2);
	new DataView(b.buffer).setUint16(0, n, true);
	return b;
}
function u32(n) {
	const b = /* @__PURE__ */ new Uint8Array(4);
	new DataView(b.buffer).setUint32(0, n, true);
	return b;
}
function concat(parts) {
	const len = parts.reduce((n, p) => n + p.length, 0);
	const out = new Uint8Array(len);
	let o = 0;
	for (const p of parts) {
		out.set(p, o);
		o += p.length;
	}
	return out;
}
function buildZip(entries) {
	const locals = [];
	const centrals = [];
	let offset = 0;
	for (const entry of entries) {
		const name = strBytes(entry.name);
		const crc = crc32(entry.data);
		const local = concat([
			u32(67324752),
			u16(20),
			u16(0),
			u16(0),
			u16(0),
			u16(0),
			u32(crc),
			u32(entry.data.length),
			u32(entry.data.length),
			u16(name.length),
			u16(0),
			name,
			entry.data
		]);
		const central = concat([
			u32(33639248),
			u16(20),
			u16(20),
			u16(0),
			u16(0),
			u16(0),
			u16(0),
			u32(crc),
			u32(entry.data.length),
			u32(entry.data.length),
			u16(name.length),
			u16(0),
			u16(0),
			u16(0),
			u16(0),
			u32(0),
			u32(offset),
			name
		]);
		locals.push(local);
		centrals.push(central);
		offset += local.length;
	}
	const centralDir = concat(centrals);
	const eocd = concat([
		u32(101010256),
		u16(0),
		u16(0),
		u16(entries.length),
		u16(entries.length),
		u32(centralDir.length),
		u32(offset),
		u16(0)
	]);
	const payload = concat([
		...locals,
		centralDir,
		eocd
	]);
	const copy = new ArrayBuffer(payload.byteLength);
	new Uint8Array(copy).set(payload);
	return new Blob([copy], { type: "application/zip" });
}
function slug(name) {
	return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "sticker-pack";
}
async function packToZip(pack) {
	const folder = slug(pack.name);
	const entries = [];
	const stickerFiles = [];
	for (let i = 0; i < pack.stickers.length; i++) {
		const sticker = pack.stickers[i];
		const file = `sticker-${String(i + 1).padStart(2, "0")}.webp`;
		entries.push({
			name: `${folder}/${file}`,
			data: await blobToBytes(dataUrlToBlob(sticker.imageWebp))
		});
		stickerFiles.push({
			image_file: file,
			emojis: (sticker.emojis || "😀").split(" ").filter(Boolean).slice(0, 3)
		});
	}
	if (pack.trayImage) entries.push({
		name: `${folder}/tray.png`,
		data: await blobToBytes(dataUrlToBlob(pack.trayImage))
	});
	const meta = {
		identifier: pack.shareId,
		name: pack.name,
		publisher: pack.artist,
		tray_image_file: pack.trayImage ? "tray.png" : "",
		stickers: stickerFiles
	};
	entries.push({
		name: `${folder}/pack.json`,
		data: strBytes(JSON.stringify(meta, null, 2))
	});
	return {
		blob: buildZip(entries),
		filename: `${folder}.zip`
	};
}
function downloadBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.rel = "noopener";
	document.body.appendChild(a);
	a.click();
	a.remove();
	setTimeout(() => URL.revokeObjectURL(url), 1500);
}
async function sharePackToDevice(pack) {
	const files = [];
	for (let i = 0; i < pack.stickers.length; i++) {
		const blob = dataUrlToBlob(pack.stickers[i].imageWebp);
		files.push(new File([blob], `${pack.name}-${String(i + 1).padStart(2, "0")}.webp`, { type: "image/webp" }));
	}
	const payload = {
		files,
		title: pack.name,
		text: `${pack.name} oleh ${pack.artist}`
	};
	if (typeof navigator !== "undefined" && typeof navigator.share === "function") {
		if (typeof navigator.canShare === "function" ? navigator.canShare(payload) : true) {
			await navigator.share(payload);
			return "shared";
		}
	}
	const zip = await packToZip(pack);
	downloadBlob(zip.blob, zip.filename);
	return "downloaded";
}
function shareLinkFor(shareId) {
	if (typeof window === "undefined") return `/s/${shareId}`;
	return `${window.location.origin}/s/${shareId}`;
}
function SendDialog({ pack, open, onOpenChange }) {
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const tooFew = pack.stickers.length < 3;
	const link = pack.status === "saved" && pack.shareId !== "draft" ? shareLinkFor(pack.shareId) : null;
	async function share() {
		if (pack.stickers.length === 0) {
			toast.error("Belum ada stiker untuk dikirim");
			return;
		}
		setBusy("share");
		try {
			const result = await sharePackToDevice(pack);
			toast.success(result === "shared" ? "Pilih WhatsApp di menu berbagi, lalu kirim sebagai stiker." : "Pack diunduh. Buka file WebP lalu bagikan ke WhatsApp.");
		} catch (err) {
			if (err instanceof Error && err.name === "AbortError") return;
			toast.error("Tidak bisa membuka berbagi. Coba unduh pack-nya.");
		} finally {
			setBusy(null);
		}
	}
	async function download() {
		if (pack.stickers.length === 0) {
			toast.error("Belum ada stiker");
			return;
		}
		setBusy("zip");
		try {
			const zip = await packToZip(pack);
			downloadBlob(zip.blob, zip.filename);
			toast.success("Pack diunduh");
		} catch {
			toast.error("Gagal mengunduh");
		} finally {
			setBusy(null);
		}
	}
	async function copyLink() {
		if (!link) return;
		try {
			await navigator.clipboard.writeText(link);
			setCopied(true);
			toast.success("Tautan disalin");
			setTimeout(() => setCopied(false), 1500);
		} catch {
			toast.error("Tidak bisa menyalin tautan");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Kirim ke WhatsApp" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Browser tidak bisa memasang pack langsung ke baki stiker WhatsApp. Kirim file WebP ke chat — di HP, WhatsApp menawarkannya sebagai stiker." })] }),
			tooFew ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-md bg-muted px-3 py-2 text-sm text-muted-foreground",
				children: [
					"Pack resmi WhatsApp butuh 3–30 stiker. Kamu punya ",
					pack.stickers.length,
					". Boleh tetap kirim yang ada."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						onClick: share,
						disabled: busy !== null,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" }), busy === "share" ? "Menyiapkan…" : "Bagikan ke WhatsApp"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						onClick: download,
						disabled: busy !== null,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), busy === "zip" ? "Mengemas…" : "Unduh pack (ZIP)"]
					}),
					link ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						onClick: copyLink,
						children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "Salin tautan pack"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Simpan pack ke profil untuk mendapat tautan yang bisa dibagikan."
					})
				]
			})
		] })
	});
}
//#endregion
export { processSticker as i, SendDialog as n, makeTrayIcon as r, ChatPreview as t };
