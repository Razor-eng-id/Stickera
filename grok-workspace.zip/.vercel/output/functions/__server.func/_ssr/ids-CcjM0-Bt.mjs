//#region node_modules/.nitro/vite/services/ssr/assets/ids-CcjM0-Bt.js
function newId(prefix) {
	return `${prefix}_${crypto.randomUUID().replaceAll("-", "").slice(0, 16)}`;
}
function newShareId() {
	return crypto.randomUUID().replaceAll("-", "").slice(0, 10);
}
//#endregion
export { newShareId as n, newId as t };
