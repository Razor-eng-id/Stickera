import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link, b as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as signIn, t as authClient } from "./client-B40BzJxt.mjs";
import { t as GROK_PROVIDERS } from "./server-DUbCfkNg.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Route$4 } from "./router-ODedQPIH.mjs";
import { a as useCurrentUserState, n as Logo, r as cn, t as Button } from "./button-DIbJSJWX.mjs";
import { n as Label, t as Input } from "./label-B1gzM7dO.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-DJto7SZG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-11 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex h-9 flex-1 items-center justify-center rounded-sm px-3 text-sm font-medium whitespace-nowrap transition-[background-color,color] duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-card data-[state=active]:text-foreground data-[state=active]:shadow-(--shadow-border)", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-4 focus-visible:outline-none", className),
	...props
}));
TabsContent.displayName = Content.displayName;
function GoogleGlyph() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className: "size-4",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#4285F4",
				d: "M23.5 12.3c0-.85-.07-1.66-.21-2.44H12v4.62h6.46c-.28 1.5-1.12 2.77-2.4 3.62v3h3.88c2.27-2.09 3.56-5.17 3.56-8.8z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#34A853",
				d: "M12 24c3.24 0 5.96-1.07 7.95-2.9l-3.88-3c-1.08.74-2.46 1.18-4.07 1.18-3.13 0-5.78-2.11-6.73-4.96H1.27v3.09C3.25 21.3 7.31 24 12 24z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#FBBC05",
				d: "M5.27 14.32A7.2 7.2 0 0 1 4.9 12c0-.81.14-1.59.37-2.32V6.59H1.27A12 12 0 0 0 0 12c0 1.94.46 3.77 1.27 5.41l4-3.09z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#EA4335",
				d: "M12 4.75c1.76 0 3.34.6 4.58 1.79l3.44-3.44C17.95 1.19 15.24 0 12 0 7.31 0 3.25 2.7 1.27 6.59l4 3.09C6.22 6.86 8.87 4.75 12 4.75z"
			})
		]
	});
}
function XGlyph() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: "size-4",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: "currentColor",
			d: "M18.2 2H21l-6.5 7.43L22 22h-6.8l-4.4-6.3L6 22H3.2l7-8.01L2 2h7l4 5.8L18.2 2Zm-1.2 18h1.9L7.1 3.9H5.1L17 20Z"
		})
	});
}
function LoginPage() {
	const { next = "/" } = Route$4.useSearch();
	const router = useRouter();
	const { user, isPending } = useCurrentUserState();
	const [oauthBusy, setOauthBusy] = (0, import_react.useState)(null);
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [formBusy, setFormBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!isPending && user) router.history.push(next);
	}, [
		isPending,
		user,
		next,
		router
	]);
	async function onOauth(providerId) {
		setOauthBusy(providerId);
		try {
			await signIn(providerId, {
				callbackURL: next,
				errorCallbackURL: "/login"
			});
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Gagal masuk");
			setOauthBusy(null);
		}
	}
	async function onEmailSignIn(e) {
		e.preventDefault();
		setFormBusy(true);
		try {
			const { error } = await authClient.signIn.email({
				email,
				password
			});
			if (error) throw new Error(error.message ?? "Email atau kata sandi salah");
			await authClient.getSession();
			router.history.push(next);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Gagal masuk");
		} finally {
			setFormBusy(false);
		}
	}
	async function onEmailSignUp(e) {
		e.preventDefault();
		if (password.length < 8) {
			toast.error("Kata sandi minimal 8 karakter");
			return;
		}
		setFormBusy(true);
		try {
			const { error } = await authClient.signUp.email({
				email,
				password,
				name: name.trim() || email.split("@")[0] || "Pengguna"
			});
			if (error) throw new Error(error.message ?? "Gagal membuat akun");
			await authClient.getSession();
			router.history.push(next);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Gagal daftar");
		} finally {
			setFormBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "paper-grid relative min-h-dvh px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-md flex-col gap-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "self-start",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rise-in rounded-xl bg-card p-6 shadow-(--shadow-lift) sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl font-medium tracking-tight",
							children: "Masuk ke studio"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "Profil menyimpan pack stiker kamu. Masuk dengan Google, X, atau daftar pakai email."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 grid gap-2",
							children: GROK_PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								className: "h-12 justify-center",
								disabled: oauthBusy !== null,
								onClick: () => void onOauth(p.providerId),
								children: [p.idp === "google" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoogleGlyph, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(XGlyph, {}), oauthBusy === p.providerId ? "Membuka…" : `Lanjut dengan ${p.label}`]
							}, p.providerId))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative my-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px bg-border" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-card px-3 text-xs text-muted-foreground",
								children: "atau daftar dengan email"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
							defaultValue: "signup",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
									className: "w-full",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
										value: "signup",
										children: "Daftar"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
										value: "signin",
										children: "Masuk"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
									value: "signup",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
										onSubmit: onEmailSignUp,
										className: "grid gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "name",
													children: "Nama"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "name",
													value: name,
													onChange: (e) => setName(e.target.value),
													placeholder: "Nama di profil",
													autoComplete: "name"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "email-up",
													children: "Email"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "email-up",
													type: "email",
													value: email,
													onChange: (e) => setEmail(e.target.value),
													required: true,
													autoComplete: "email"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "password-up",
													children: "Kata sandi"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "password-up",
													type: "password",
													value: password,
													onChange: (e) => setPassword(e.target.value),
													required: true,
													minLength: 8,
													autoComplete: "new-password"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "submit",
												disabled: formBusy || false,
												children: formBusy ? "Mendaftar…" : "Buat profil"
											})
										]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
									value: "signin",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
										onSubmit: onEmailSignIn,
										className: "grid gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "email-in",
													children: "Email"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "email-in",
													type: "email",
													value: email,
													onChange: (e) => setEmail(e.target.value),
													required: true,
													autoComplete: "email"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "password-in",
													children: "Kata sandi"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "password-in",
													type: "password",
													value: password,
													onChange: (e) => setPassword(e.target.value),
													required: true,
													autoComplete: "current-password"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "submit",
												disabled: formBusy || false,
												children: formBusy ? "Masuk…" : "Masuk dengan email"
											})
										]
									})
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-xs text-muted-foreground",
					children: "Dengan masuk, pack yang kamu simpan terikat ke profil ini."
				})
			]
		})
	});
}
//#endregion
export { LoginPage as component };
