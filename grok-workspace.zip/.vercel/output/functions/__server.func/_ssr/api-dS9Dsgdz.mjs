import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { r as getSql } from "./db-Bzkm0s_E.mjs";
import { t as authMiddleware } from "./middleware-D8Cj4eP7.mjs";
import { n as newShareId, t as newId } from "./ids-CcjM0-Bt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-dS9Dsgdz.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function toSummary(row) {
	return {
		id: row.id,
		name: row.name,
		artist: row.artist,
		trayImage: row.tray_image,
		shareId: row.share_id,
		status: row.status,
		stickerCount: Number(row.sticker_count) || 0,
		createdAt: row.created_at,
		updatedAt: row.updated_at
	};
}
function toSticker(row) {
	return {
		id: row.id,
		packId: row.pack_id,
		imageWebp: row.image_webp,
		emojis: row.emojis,
		sortOrder: row.sort_order,
		byteSize: row.byte_size,
		createdAt: row.created_at
	};
}
var listPacks_createServerFn_handler = createServerRpc({
	id: "7950e6072ab716895021fc329b6c6ecd826acf25fc772513c7d9862b9953e4b0",
	name: "listPacks",
	filename: "src/lib/stickers/api.ts"
}, (opts) => listPacks.__executeServer(opts));
var listPacks = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listPacks_createServerFn_handler, async ({ context }) => {
	return (await (await getSql())`
      select
        p.id, p.name, p.artist, p.tray_image, p.share_id, p.status,
        p.created_at, p.updated_at,
        coalesce((select count(*) from stickers s where s.pack_id = p.id), 0)::int as sticker_count
      from sticker_packs p
      where p.user_id = ${context.userId}
      order by p.updated_at desc
    `).map(toSummary);
});
var getPack_createServerFn_handler = createServerRpc({
	id: "3a3b11ae38ba89321405094045e59cdf081946c7684a7e200cc49b5e5bbf52fa",
	name: "getPack",
	filename: "src/lib/stickers/api.ts"
}, (opts) => getPack.__executeServer(opts));
var getPack = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((id) => id).handler(getPack_createServerFn_handler, async ({ context, data: id }) => {
	const sql = await getSql();
	const pack = (await sql`
      select
        p.id, p.name, p.artist, p.tray_image, p.share_id, p.status,
        p.created_at, p.updated_at,
        coalesce((select count(*) from stickers s where s.pack_id = p.id), 0)::int as sticker_count
      from sticker_packs p
      where p.id = ${id} and p.user_id = ${context.userId}
      limit 1
    `)[0];
	if (!pack) return null;
	const stickers = await sql`
      select id, pack_id, image_webp, emojis, sort_order, byte_size, created_at
      from stickers
      where pack_id = ${id} and user_id = ${context.userId}
      order by sort_order asc, created_at asc
    `;
	return {
		...toSummary(pack),
		stickers: stickers.map(toSticker)
	};
});
var getPublicPack_createServerFn_handler = createServerRpc({
	id: "5ab0bc3ae481af3bfe2d5dfe546616230a45374095d314022fbc40cf8b12e08e",
	name: "getPublicPack",
	filename: "src/lib/stickers/api.ts"
}, (opts) => getPublicPack.__executeServer(opts));
var getPublicPack = createServerFn({ method: "GET" }).validator((shareId) => shareId).handler(getPublicPack_createServerFn_handler, async ({ data: shareId }) => {
	const sql = await getSql();
	const pack = (await sql`
      select
        p.id, p.name, p.artist, p.tray_image, p.share_id, p.status,
        p.created_at, p.updated_at,
        coalesce((select count(*) from stickers s where s.pack_id = p.id), 0)::int as sticker_count
      from sticker_packs p
      where p.share_id = ${shareId} and p.status = 'saved'
      limit 1
    `)[0];
	if (!pack) return null;
	const stickers = await sql`
      select id, pack_id, image_webp, emojis, sort_order, byte_size, created_at
      from stickers
      where pack_id = ${pack.id}
      order by sort_order asc, created_at asc
    `;
	return {
		...toSummary(pack),
		stickers: stickers.map(toSticker)
	};
});
var createPack_createServerFn_handler = createServerRpc({
	id: "6f3a46375460f2bdcbbf1e4c104d91586fa41d21474829f7bdb1739bd1714890",
	name: "createPack",
	filename: "src/lib/stickers/api.ts"
}, (opts) => createPack.__executeServer(opts));
var createPack = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const name = input.name.trim().slice(0, 128);
	const artist = input.artist.trim().slice(0, 128);
	if (!name) throw new Error("Nama pack wajib diisi");
	if (!artist) throw new Error("Nama artis wajib diisi");
	return {
		name,
		artist
	};
}).handler(createPack_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const id = newId("pack");
	const shareId = newShareId();
	await sql`
      insert into sticker_packs (id, user_id, name, artist, share_id, status)
      values (${id}, ${context.userId}, ${data.name}, ${data.artist}, ${shareId}, 'draft')
    `;
	return {
		id,
		shareId
	};
});
var updatePackMeta_createServerFn_handler = createServerRpc({
	id: "4f040739524aeae7f4522974a2c9da508ab5b5caa1fbbdcd5846398358d8fcc2",
	name: "updatePackMeta",
	filename: "src/lib/stickers/api.ts"
}, (opts) => updatePackMeta.__executeServer(opts));
var updatePackMeta = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(updatePackMeta_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const name = data.name.trim().slice(0, 128);
	const artist = data.artist.trim().slice(0, 128);
	if (!name || !artist) throw new Error("Nama pack dan artis wajib diisi");
	await sql`
      update sticker_packs
      set name = ${name},
          artist = ${artist},
          tray_image = ${data.trayImage ?? null},
          updated_at = now()
      where id = ${data.id} and user_id = ${context.userId}
    `;
	return { ok: true };
});
var savePackToProfile_createServerFn_handler = createServerRpc({
	id: "1cc51caa24f1373f42e200c38fba098c8dde860900dd72595468ef31111d08ee",
	name: "savePackToProfile",
	filename: "src/lib/stickers/api.ts"
}, (opts) => savePackToProfile.__executeServer(opts));
var savePackToProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(savePackToProfile_createServerFn_handler, async ({ context, data: id }) => {
	const sql = await getSql();
	if (((await sql`
      select count(*)::int as n from stickers where pack_id = ${id} and user_id = ${context.userId}
    `)[0]?.n ?? 0) < 1) throw new Error("Tambahkan stiker dulu sebelum menyimpan pack");
	await sql`
      update sticker_packs
      set status = 'saved', updated_at = now()
      where id = ${id} and user_id = ${context.userId}
    `;
	return { ok: true };
});
var deletePack_createServerFn_handler = createServerRpc({
	id: "14f3ccce267d6602f9c1459a0df0147950d5b6d2f9c68a33109152d8b204f20b",
	name: "deletePack",
	filename: "src/lib/stickers/api.ts"
}, (opts) => deletePack.__executeServer(opts));
var deletePack = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(deletePack_createServerFn_handler, async ({ context, data: id }) => {
	const sql = await getSql();
	await sql`delete from stickers where pack_id = ${id} and user_id = ${context.userId}`;
	await sql`delete from sticker_packs where id = ${id} and user_id = ${context.userId}`;
	return { ok: true };
});
var addStickers_createServerFn_handler = createServerRpc({
	id: "a3e86de6fa1e5d8c11508c99ff031e5252e5b2dc4bcdbad8693839b64faadc1c",
	name: "addStickers",
	filename: "src/lib/stickers/api.ts"
}, (opts) => addStickers.__executeServer(opts));
var addStickers = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(addStickers_createServerFn_handler, async ({ context, data }) => {
	if (data.stickers.length < 1) return { ids: [] };
	const sql = await getSql();
	if (!(await sql`
      select id from sticker_packs where id = ${data.packId} and user_id = ${context.userId} limit 1
    `)[0]) throw new Error("Pack tidak ditemukan");
	const existing = (await sql`
      select count(*)::int as n from stickers where pack_id = ${data.packId} and user_id = ${context.userId}
    `)[0]?.n ?? 0;
	if (existing + data.stickers.length > 30) throw new Error("Maksimal 30 stiker per pack");
	const ids = [];
	let order = existing;
	for (const sticker of data.stickers) {
		if (!sticker.imageWebp.startsWith("data:image/webp")) throw new Error("Format stiker harus WebP");
		if (sticker.imageWebp.length > 25e4) throw new Error("Stiker terlalu besar");
		const id = newId("stk");
		await sql`
        insert into stickers (id, pack_id, user_id, image_webp, emojis, sort_order, byte_size)
        values (
          ${id},
          ${data.packId},
          ${context.userId},
          ${sticker.imageWebp},
          ${sticker.emojis?.slice(0, 16) || "😀"},
          ${order},
          ${sticker.byteSize}
        )
      `;
		ids.push(id);
		order += 1;
	}
	const first = await sql`
      select image_webp from stickers
      where pack_id = ${data.packId} and user_id = ${context.userId}
      order by sort_order asc
      limit 1
    `;
	if (first[0]) await sql`
        update sticker_packs
        set tray_image = coalesce(tray_image, ${first[0].image_webp}),
            updated_at = now()
        where id = ${data.packId} and user_id = ${context.userId}
      `;
	return { ids };
});
var deleteSticker_createServerFn_handler = createServerRpc({
	id: "1f027979c4e6aa30249625619cb9f1d9ab98479931f22e3f08ceedd7ae5595eb",
	name: "deleteSticker",
	filename: "src/lib/stickers/api.ts"
}, (opts) => deleteSticker.__executeServer(opts));
var deleteSticker = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(deleteSticker_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await sql`
      delete from stickers
      where id = ${data.stickerId} and pack_id = ${data.packId} and user_id = ${context.userId}
    `;
	await sql`
      update sticker_packs set updated_at = now()
      where id = ${data.packId} and user_id = ${context.userId}
    `;
	return { ok: true };
});
var importDraftPack_createServerFn_handler = createServerRpc({
	id: "70790bc0279fe6e2da584222e4f3f37b802aeaa39d5a40535b7dc12df2546fc6",
	name: "importDraftPack",
	filename: "src/lib/stickers/api.ts"
}, (opts) => importDraftPack.__executeServer(opts));
var importDraftPack = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(importDraftPack_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const name = data.name.trim().slice(0, 128);
	const artist = data.artist.trim().slice(0, 128);
	if (!name || !artist) throw new Error("Nama pack dan artis wajib diisi");
	const id = newId("pack");
	const shareId = newShareId();
	const status = data.stickers.length > 0 ? "saved" : "draft";
	await sql`
      insert into sticker_packs (id, user_id, name, artist, tray_image, share_id, status)
      values (${id}, ${context.userId}, ${name}, ${artist}, ${data.trayImage ?? null}, ${shareId}, ${status})
    `;
	let order = 0;
	for (const sticker of data.stickers.slice(0, 30)) {
		if (!sticker.imageWebp.startsWith("data:image/webp")) continue;
		await sql`
        insert into stickers (id, pack_id, user_id, image_webp, emojis, sort_order, byte_size)
        values (
          ${newId("stk")},
          ${id},
          ${context.userId},
          ${sticker.imageWebp},
          ${sticker.emojis?.slice(0, 16) || "😀"},
          ${order},
          ${sticker.byteSize}
        )
      `;
		order += 1;
	}
	return {
		id,
		shareId
	};
});
//#endregion
export { addStickers_createServerFn_handler, createPack_createServerFn_handler, deletePack_createServerFn_handler, deleteSticker_createServerFn_handler, getPack_createServerFn_handler, getPublicPack_createServerFn_handler, importDraftPack_createServerFn_handler, listPacks_createServerFn_handler, savePackToProfile_createServerFn_handler, updatePackMeta_createServerFn_handler };
