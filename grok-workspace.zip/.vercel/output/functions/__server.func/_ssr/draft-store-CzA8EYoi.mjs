import { n as DRAFT_PACK_ID } from "./types-NQi8Ka8c.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/draft-store-CzA8EYoi.js
function emptyPack(name, artist) {
	const now = (/* @__PURE__ */ new Date()).toISOString();
	return {
		id: DRAFT_PACK_ID,
		name,
		artist,
		trayImage: null,
		shareId: "draft",
		status: "draft",
		stickerCount: 0,
		createdAt: now,
		updatedAt: now,
		stickers: []
	};
}
var useDraftStore = create()(persist((set, get) => ({
	pack: null,
	setMeta: (name, artist) => {
		const current = get().pack;
		set({ pack: current ? {
			...current,
			name,
			artist,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		} : emptyPack(name, artist) });
	},
	setPack: (pack) => set({ pack }),
	addStickers: (stickers) => {
		const current = get().pack ?? emptyPack("Pack baru", "Artis");
		const next = [...current.stickers, ...stickers].map((s, i) => ({
			...s,
			sortOrder: i
		}));
		set({ pack: {
			...current,
			stickers: next,
			stickerCount: next.length,
			trayImage: current.trayImage ?? next[0]?.imageWebp ?? null,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		} });
	},
	removeSticker: (id) => {
		const current = get().pack;
		if (!current) return;
		const next = current.stickers.filter((s) => s.id !== id).map((s, i) => ({
			...s,
			sortOrder: i
		}));
		set({ pack: {
			...current,
			stickers: next,
			stickerCount: next.length,
			trayImage: next[0]?.imageWebp ?? null,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		} });
	},
	updateSticker: (id, patch) => {
		const current = get().pack;
		if (!current) return;
		set({ pack: {
			...current,
			stickers: current.stickers.map((s) => s.id === id ? {
				...s,
				...patch
			} : s),
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		} });
	},
	setTray: (trayImage) => {
		const current = get().pack;
		if (!current) return;
		set({ pack: {
			...current,
			trayImage,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		} });
	},
	clear: () => set({ pack: null })
}), { name: "stikera-draft" }));
//#endregion
export { useDraftStore as t };
