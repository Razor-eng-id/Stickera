import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as Route$1 } from "./router-ODedQPIH.mjs";
import { t as Button } from "./button-DIbJSJWX.mjs";
import { f as getPublicPack, o as Skeleton, t as AppShell } from "./api-mfaWCtwL.mjs";
import { n as SendDialog, t as ChatPreview } from "./send-dialog-KxyITUak.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/s._shareId-resM1jkP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PublicPackPage() {
	const { shareId } = Route$1.useParams();
	const [sendOpen, setSendOpen] = (0, import_react.useState)(false);
	const query = useQuery({
		queryKey: ["public-pack", shareId],
		queryFn: () => getPublicPack({ data: shareId })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto w-full max-w-3xl px-4 py-10",
		children: query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64 w-full rounded-xl" }) : !query.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl",
					children: "Pack tidak tersedia"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Pack ini belum disimpan ke profil, atau tautannya tidak valid."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						children: "Buat pack sendiri"
					})
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase",
						children: "Pack stiker"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-4xl font-medium tracking-tight",
						children: query.data.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-muted-foreground",
						children: ["oleh ", query.data.artist]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2 sm:grid-cols-4",
					children: query.data.stickers.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sticker-checker aspect-square overflow-hidden rounded-lg bg-card shadow-(--shadow-border)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: s.imageWebp,
							alt: "",
							className: "size-full object-contain p-1"
						})
					}, s.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatPreview, { pack: query.data }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: () => setSendOpen(true),
						children: "Kirim ke WhatsApp"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							children: "Bikin pack sendiri"
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SendDialog, {
					pack: query.data,
					open: sendOpen,
					onOpenChange: setSendOpen
				})
			]
		})
	}) });
}
//#endregion
export { PublicPackPage as component };
