import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Trash2, d as Ellipsis } from "../_libs/lucide-react.mjs";
import { t as Button } from "./button-DIbJSJWX.mjs";
import { a as DropdownMenuTrigger, i as DropdownMenuItem, n as DropdownMenu, r as DropdownMenuContent } from "./api-mfaWCtwL.mjs";
import { t as Badge } from "./badge-CnPWTdT1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pack-card-Dso3xp-Y.js
var import_jsx_runtime = require_jsx_runtime();
function PackCard({ pack, onDelete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group relative flex flex-col overflow-hidden rounded-xl bg-card shadow-(--shadow-border) transition-[box-shadow,transform] duration-200 hover:shadow-(--shadow-border-hover)",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/pack/$packId",
			params: { packId: pack.id },
			className: "flex flex-1 flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sticker-checker relative aspect-square",
					children: pack.trayImage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: pack.trayImage,
						alt: "",
						className: "absolute inset-0 size-full object-contain p-6"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 grid place-items-center text-sm text-muted-foreground",
						children: "Belum ada stiker"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-2 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "truncate font-display text-base font-medium",
							children: pack.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm text-muted-foreground",
							children: pack.artist
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: pack.status === "saved" ? "secondary" : "muted",
						children: pack.status === "saved" ? "Tersimpan" : "Draf"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "px-4 pb-4 text-xs tabular-nums text-muted-foreground",
					children: [pack.stickerCount, "/30 stiker"]
				})
			]
		}), onDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute right-2 top-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "icon-sm",
					variant: "outline",
					className: "bg-card/90",
					"aria-label": "Opsi pack",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent, {
				align: "end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					className: "text-destructive",
					onSelect: () => onDelete(pack.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Hapus pack"]
				})
			})] })
		}) : null]
	});
}
//#endregion
export { PackCard as t };
