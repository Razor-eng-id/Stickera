//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DjvFKOEN.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/profile",
			"/pack/$packId",
			"/s/$shareId",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-C5-PUpx-.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/preload-helper-COb1fLmP.js",
			"/assets/query-BUdKLR-G.js",
			"/assets/lazyRouteComponent-DKmg7AZH.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C5-PUpx-.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DlSdqcZk.js",
			"/assets/api-CusaQuDI.js",
			"/assets/pack-card-BzQFVtNC.js",
			"/assets/draft-store-DPqbZ0sV.js",
			"/assets/types-Bu3kCtm2.js",
			"/assets/dist-C7cYGDbh.js",
			"/assets/label-C5oxOGXR.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-CQPWnTAD.js",
			"/assets/client-DRhaju3Z.js",
			"/assets/dist-C7cYGDbh.js",
			"/assets/label-C5oxOGXR.js"
		]
	},
	"/profile": {
		filePath: "/workspace/src/routes/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-zrvony1p.js",
			"/assets/api-CusaQuDI.js",
			"/assets/pack-card-BzQFVtNC.js",
			"/assets/dist-C7cYGDbh.js"
		]
	},
	"/pack/$packId": {
		filePath: "/workspace/src/routes/pack.$packId.tsx",
		children: void 0,
		preloads: [
			"/assets/pack._packId-CDMZUM1T.js",
			"/assets/api-CusaQuDI.js",
			"/assets/send-dialog-CcPwzpGc.js",
			"/assets/draft-store-DPqbZ0sV.js",
			"/assets/types-Bu3kCtm2.js",
			"/assets/badge-C7dyK2MV.js",
			"/assets/dist-C7cYGDbh.js",
			"/assets/label-C5oxOGXR.js"
		]
	},
	"/s/$shareId": {
		filePath: "/workspace/src/routes/s.$shareId.tsx",
		children: void 0,
		preloads: [
			"/assets/s._shareId-b5SVEhXX.js",
			"/assets/api-CusaQuDI.js",
			"/assets/send-dialog-CcPwzpGc.js",
			"/assets/dist-C7cYGDbh.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
