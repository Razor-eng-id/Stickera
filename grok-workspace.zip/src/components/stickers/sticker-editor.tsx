import { Plus, Trash2, Upload } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { processSticker } from "@/lib/stickers/process";
import {
  DEFAULT_PROCESS,
  MAX_STICKER_BYTES,
  MAX_STICKERS,
  type PackDetail,
  type ProcessOptions,
  type StickerRecord,
} from "@/lib/stickers/types";
import { newId } from "@/lib/stickers/ids";

function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  return `${Math.round(n / 1024)} KB`;
}

export function StickerEditor({
  pack,
  onAdd,
  onRemove,
  disabled,
}: {
  pack: PackDetail;
  onAdd: (stickers: StickerRecord[]) => Promise<void> | void;
  onRemove: (id: string) => Promise<void> | void;
  disabled?: boolean;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [options, setOptions] = useState<ProcessOptions>(DEFAULT_PROCESS);
  const [processing, setProcessing] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const remaining = MAX_STICKERS - pack.stickers.length;

  async function handleFiles(files: FileList | File[]) {
    const list = Array.from(files).filter((f) => f.type.startsWith("image/"));
    if (list.length === 0) {
      toast.error("Pilih file gambar");
      return;
    }
    if (remaining <= 0) {
      toast.error("Pack sudah penuh (30 stiker)");
      return;
    }
    const take = list.slice(0, remaining);
    if (take.length < list.length) {
      toast.message(`Hanya ${take.length} gambar yang ditambah (batas 30)`);
    }
    setProcessing(true);
    try {
      const next: StickerRecord[] = [];
      let gifCount = 0;
      for (const file of take) {
        const processed = await processSticker(file, options);
        if (processed.wasGif) gifCount += 1;
        next.push({
          id: newId("stk"),
          packId: pack.id,
          imageWebp: processed.dataUrl,
          emojis: "😀",
          sortOrder: pack.stickers.length + next.length,
          byteSize: processed.bytes,
          createdAt: new Date().toISOString(),
        });
      }
      await onAdd(next);
      if (gifCount) {
        toast.message("GIF dipakai sebagai stiker statis (frame pertama).");
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal memproses gambar");
    } finally {
      setProcessing(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <ToggleChip
          label="Hapus latar"
          active={options.removeBackground}
          onClick={() => setOptions((o) => ({ ...o, removeBackground: !o.removeBackground }))}
        />
        <ToggleChip
          label="Garis tepi"
          active={options.outline}
          onClick={() => setOptions((o) => ({ ...o, outline: !o.outline }))}
        />
        <ToggleChip
          label={options.fit === "contain" ? "Muat utuh" : "Potong isi"}
          active
          onClick={() =>
            setOptions((o) => ({ ...o, fit: o.fit === "contain" ? "cover" : "contain" }))
          }
        />
        <span className="ml-auto text-xs tabular-nums text-muted-foreground">
          {pack.stickers.length}/{MAX_STICKERS}
        </span>
      </div>

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        multiple
        className="sr-only"
        onChange={(e) => {
          if (e.target.files) void handleFiles(e.target.files);
        }}
      />

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          if (e.dataTransfer.files.length) void handleFiles(e.dataTransfer.files);
        }}
        className={cn(
          "grid grid-cols-3 gap-2 sm:grid-cols-4 md:grid-cols-5",
          dragOver && "rounded-xl ring-2 ring-ring/40",
        )}
      >
        {pack.stickers.map((sticker) => (
          <StickerTile
            key={sticker.id}
            sticker={sticker}
            onRemove={() => void onRemove(sticker.id)}
            disabled={disabled || processing}
          />
        ))}
        {remaining > 0 ? (
          <button
            type="button"
            disabled={disabled || processing}
            onClick={() => inputRef.current?.click()}
            className="sticker-checker relative flex aspect-square flex-col items-center justify-center gap-2 rounded-lg bg-card text-muted-foreground shadow-(--shadow-border) transition-[box-shadow,transform] duration-150 hover:shadow-(--shadow-border-hover) active:scale-[0.96] disabled:opacity-60"
          >
            <span className="grid size-12 place-items-center rounded-full bg-primary text-primary-foreground">
              {processing ? (
                <Upload className="size-5 animate-pulse" />
              ) : (
                <Plus className="size-6" />
              )}
            </span>
            <span className="px-2 text-center text-xs">
              {processing ? "Memproses…" : "Unggah gambar"}
            </span>
          </button>
        ) : null}
      </div>
    </div>
  );
}

function ToggleChip({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-9 rounded-full px-3 text-xs font-medium transition-colors duration-150",
        active ? "bg-secondary text-secondary-foreground" : "bg-muted text-muted-foreground",
      )}
    >
      {label}
    </button>
  );
}

function StickerTile({
  sticker,
  onRemove,
  disabled,
}: {
  sticker: StickerRecord;
  onRemove: () => void;
  disabled?: boolean;
}) {
  const over = sticker.byteSize > MAX_STICKER_BYTES;
  return (
    <div className="group relative aspect-square overflow-hidden rounded-lg bg-card shadow-(--shadow-border)">
      <div className="sticker-checker absolute inset-0">
        <img src={sticker.imageWebp} alt="" className="size-full object-contain p-1" />
      </div>
      <Badge
        variant={over ? "default" : "muted"}
        className={cn(
          "absolute left-1.5 top-1.5 tabular-nums",
          over && "bg-destructive text-destructive-foreground",
        )}
      >
        {formatBytes(sticker.byteSize)}
      </Badge>
      <button
        type="button"
        disabled={disabled}
        onClick={onRemove}
        aria-label="Hapus stiker"
        className="absolute right-1.5 top-1.5 grid size-9 place-items-center rounded-full bg-card/95 text-foreground opacity-100 shadow-(--shadow-border) transition-opacity sm:opacity-0 sm:group-hover:opacity-100"
      >
        <Trash2 className="size-4" />
      </button>
    </div>
  );
}
