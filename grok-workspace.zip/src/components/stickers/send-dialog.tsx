import { Check, Copy, Download, Share2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { shareLinkFor, sharePackToDevice } from "@/lib/stickers/share";
import { downloadBlob, packToZip } from "@/lib/stickers/zip";
import type { PackDetail } from "@/lib/stickers/types";
import { MIN_PACK_STICKERS } from "@/lib/stickers/types";

export function SendDialog({
  pack,
  open,
  onOpenChange,
}: {
  pack: PackDetail;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [busy, setBusy] = useState<"share" | "zip" | null>(null);
  const [copied, setCopied] = useState(false);
  const tooFew = pack.stickers.length < MIN_PACK_STICKERS;
  const link = pack.status === "saved" && pack.shareId !== "draft" ? shareLinkFor(pack.shareId) : null;

  async function share() {
    if (pack.stickers.length === 0) {
      toast.error("Belum ada stiker untuk dikirim");
      return;
    }
    setBusy("share");
    try {
      const result = await sharePackToDevice(pack);
      toast.success(
        result === "shared"
          ? "Pilih WhatsApp di menu berbagi, lalu kirim sebagai stiker."
          : "Pack diunduh. Buka file WebP lalu bagikan ke WhatsApp.",
      );
    } catch (err) {
      if (err instanceof Error && err.name === "AbortError") return;
      toast.error("Tidak bisa membuka berbagi. Coba unduh pack-nya.");
    } finally {
      setBusy(null);
    }
  }

  async function download() {
    if (pack.stickers.length === 0) {
      toast.error("Belum ada stiker");
      return;
    }
    setBusy("zip");
    try {
      const zip = await packToZip(pack);
      downloadBlob(zip.blob, zip.filename);
      toast.success("Pack diunduh");
    } catch {
      toast.error("Gagal mengunduh");
    } finally {
      setBusy(null);
    }
  }

  async function copyLink() {
    if (!link) return;
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      toast.success("Tautan disalin");
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error("Tidak bisa menyalin tautan");
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Kirim ke WhatsApp</DialogTitle>
          <DialogDescription>
            Browser tidak bisa memasang pack langsung ke baki stiker WhatsApp.
            Kirim file WebP ke chat — di HP, WhatsApp menawarkannya sebagai stiker.
          </DialogDescription>
        </DialogHeader>
        {tooFew ? (
          <p className="rounded-md bg-muted px-3 py-2 text-sm text-muted-foreground">
            Pack resmi WhatsApp butuh 3–30 stiker. Kamu punya {pack.stickers.length}.
            Boleh tetap kirim yang ada.
          </p>
        ) : null}
        <div className="grid gap-2">
          <Button type="button" onClick={share} disabled={busy !== null}>
            <Share2 className="size-4" />
            {busy === "share" ? "Menyiapkan…" : "Bagikan ke WhatsApp"}
          </Button>
          <Button type="button" variant="outline" onClick={download} disabled={busy !== null}>
            <Download className="size-4" />
            {busy === "zip" ? "Mengemas…" : "Unduh pack (ZIP)"}
          </Button>
          {link ? (
            <Button type="button" variant="outline" onClick={copyLink}>
              {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
              Salin tautan pack
            </Button>
          ) : (
            <p className="text-xs text-muted-foreground">
              Simpan pack ke profil untuk mendapat tautan yang bisa dibagikan.
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
