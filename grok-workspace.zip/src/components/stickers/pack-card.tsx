import { Link } from "@tanstack/react-router";
import { MoreHorizontal, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { PackSummary } from "@/lib/stickers/types";

export function PackCard({
  pack,
  onDelete,
}: {
  pack: PackSummary;
  onDelete?: (id: string) => void;
}) {
  return (
    <article className="group relative flex flex-col overflow-hidden rounded-xl bg-card shadow-(--shadow-border) transition-[box-shadow,transform] duration-200 hover:shadow-(--shadow-border-hover)">
      <Link
        to="/pack/$packId"
        params={{ packId: pack.id }}
        className="flex flex-1 flex-col"
      >
        <div className="sticker-checker relative aspect-square">
          {pack.trayImage ? (
            <img
              src={pack.trayImage}
              alt=""
              className="absolute inset-0 size-full object-contain p-6"
            />
          ) : (
            <div className="absolute inset-0 grid place-items-center text-sm text-muted-foreground">
              Belum ada stiker
            </div>
          )}
        </div>
        <div className="flex items-start justify-between gap-2 p-4">
          <div className="min-w-0">
            <h3 className="truncate font-display text-base font-medium">{pack.name}</h3>
            <p className="truncate text-sm text-muted-foreground">{pack.artist}</p>
          </div>
          <Badge variant={pack.status === "saved" ? "secondary" : "muted"}>
            {pack.status === "saved" ? "Tersimpan" : "Draf"}
          </Badge>
        </div>
        <p className="px-4 pb-4 text-xs tabular-nums text-muted-foreground">
          {pack.stickerCount}/30 stiker
        </p>
      </Link>
      {onDelete ? (
        <div className="absolute right-2 top-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                type="button"
                size="icon-sm"
                variant="outline"
                className="bg-card/90"
                aria-label="Opsi pack"
              >
                <MoreHorizontal className="size-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                className="text-destructive"
                onSelect={() => onDelete(pack.id)}
              >
                <Trash2 className="size-4" />
                Hapus pack
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ) : null}
    </article>
  );
}
