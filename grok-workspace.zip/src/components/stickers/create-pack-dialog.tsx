import { useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { createPack } from "@/lib/stickers/api";
import { useDraftStore } from "@/lib/stickers/draft-store";
import { useCurrentUser } from "@/lib/auth/use-current-user";

export function CreatePackDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const navigate = useNavigate();
  const user = useCurrentUser();
  const setMeta = useDraftStore((s) => s.setMeta);
  const [name, setName] = useState("");
  const [artist, setArtist] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const packName = name.trim();
    const packArtist = artist.trim();
    if (!packName || !packArtist) {
      toast.error("Isi nama pack dan nama artis");
      return;
    }
    setBusy(true);
    try {
      if (user) {
        const created = await createPack({ data: { name: packName, artist: packArtist } });
        onOpenChange(false);
        setName("");
        setArtist("");
        await navigate({ to: "/pack/$packId", params: { packId: created.id } });
      } else {
        setMeta(packName, packArtist);
        onOpenChange(false);
        await navigate({ to: "/pack/$packId", params: { packId: "draft" } });
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Gagal membuat pack";
      if (message === "Unauthorized") {
        setMeta(packName, packArtist);
        await navigate({ to: "/login", search: { next: "/pack/draft" } });
        return;
      }
      toast.error(message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <form onSubmit={submit} className="grid gap-4">
          <DialogHeader>
            <DialogTitle>Pack stiker baru</DialogTitle>
            <DialogDescription>
              Mulai dari nama pack dan artisnya. Setelah itu kamu bisa unggah gambar lewat tombol plus.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-2">
            <Label htmlFor="pack-name">Nama pack</Label>
            <Input
              id="pack-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Misal: Mood Hari Ini"
              maxLength={128}
              autoFocus
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="pack-artist">Nama artis</Label>
            <Input
              id="pack-artist"
              value={artist}
              onChange={(e) => setArtist(e.target.value)}
              placeholder="Nama kamu atau studio"
              maxLength={128}
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Batal
            </Button>
            <Button type="submit" disabled={busy}>
              {busy ? "Membuat…" : "Lanjut unggah"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
