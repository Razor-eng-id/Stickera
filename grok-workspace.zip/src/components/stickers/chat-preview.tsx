import type { PackDetail } from "@/lib/stickers/types";

export function ChatPreview({ pack }: { pack: PackDetail }) {
  const stickers = pack.stickers.slice(0, 6);

  return (
    <div className="overflow-hidden rounded-xl bg-chat text-primary-foreground shadow-(--shadow-lift)">
      <div className="flex items-center gap-3 border-b border-white/10 px-4 py-3">
        <div className="grid size-8 place-items-center rounded-full bg-primary text-xs font-medium">
          {pack.artist.slice(0, 1).toUpperCase() || "S"}
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm font-medium">{pack.name || "Pack stiker"}</p>
          <p className="truncate text-xs text-white/60">{pack.artist || "Artis"}</p>
        </div>
      </div>
      <div className="space-y-3 px-4 py-4">
        <div className="max-w-[85%] rounded-lg rounded-tl-sm bg-chat-bubble px-3 py-2 text-sm text-white/90">
          Kirim pack ini ke chat WhatsApp. Stiker tampil seperti ini.
        </div>
        {stickers.length === 0 ? (
          <p className="text-xs text-white/50">Unggah stiker untuk melihat pratinjau.</p>
        ) : (
          <div className="flex flex-wrap justify-end gap-2">
            {stickers.map((s) => (
              <img
                key={s.id}
                src={s.imageWebp}
                alt=""
                className="size-16 object-contain drop-shadow-sm"
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
