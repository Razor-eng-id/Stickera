import { dataUrlToBlob } from "./process";
import type { PackDetail } from "./types";

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(buf: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function strBytes(s: string): Uint8Array {
  return new TextEncoder().encode(s);
}

async function blobToBytes(blob: Blob): Promise<Uint8Array> {
  return new Uint8Array(await blob.arrayBuffer());
}

type ZipEntry = { name: string; data: Uint8Array };

function u16(n: number): Uint8Array {
  const b = new Uint8Array(2);
  new DataView(b.buffer).setUint16(0, n, true);
  return b;
}
function u32(n: number): Uint8Array {
  const b = new Uint8Array(4);
  new DataView(b.buffer).setUint32(0, n, true);
  return b;
}

function concat(parts: Uint8Array[]): Uint8Array {
  const len = parts.reduce((n, p) => n + p.length, 0);
  const out = new Uint8Array(len);
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}

function buildZip(entries: ZipEntry[]): Blob {
  const locals: Uint8Array[] = [];
  const centrals: Uint8Array[] = [];
  let offset = 0;
  for (const entry of entries) {
    const name = strBytes(entry.name);
    const crc = crc32(entry.data);
    const local = concat([
      u32(0x04034b50),
      u16(20),
      u16(0),
      u16(0),
      u16(0),
      u16(0),
      u32(crc),
      u32(entry.data.length),
      u32(entry.data.length),
      u16(name.length),
      u16(0),
      name,
      entry.data,
    ]);
    const central = concat([
      u32(0x02014b50),
      u16(20),
      u16(20),
      u16(0),
      u16(0),
      u16(0),
      u16(0),
      u32(crc),
      u32(entry.data.length),
      u32(entry.data.length),
      u16(name.length),
      u16(0),
      u16(0),
      u16(0),
      u16(0),
      u32(0),
      u32(offset),
      name,
    ]);
    locals.push(local);
    centrals.push(central);
    offset += local.length;
  }
  const centralDir = concat(centrals);
  const eocd = concat([
    u32(0x06054b50),
    u16(0),
    u16(0),
    u16(entries.length),
    u16(entries.length),
    u32(centralDir.length),
    u32(offset),
    u16(0),
  ]);
  const payload = concat([...locals, centralDir, eocd]);
  const copy = new ArrayBuffer(payload.byteLength);
  new Uint8Array(copy).set(payload);
  return new Blob([copy], { type: "application/zip" });
}

function slug(name: string): string {
  const s = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
  return s || "sticker-pack";
}

export async function packToZip(pack: PackDetail): Promise<{ blob: Blob; filename: string }> {
  const folder = slug(pack.name);
  const entries: ZipEntry[] = [];
  const stickerFiles: Array<{ image_file: string; emojis: string[] }> = [];

  for (let i = 0; i < pack.stickers.length; i++) {
    const sticker = pack.stickers[i];
    const file = `sticker-${String(i + 1).padStart(2, "0")}.webp`;
    entries.push({
      name: `${folder}/${file}`,
      data: await blobToBytes(dataUrlToBlob(sticker.imageWebp)),
    });
    stickerFiles.push({
      image_file: file,
      emojis: (sticker.emojis || "😀").split(" ").filter(Boolean).slice(0, 3),
    });
  }

  if (pack.trayImage) {
    entries.push({
      name: `${folder}/tray.png`,
      data: await blobToBytes(dataUrlToBlob(pack.trayImage)),
    });
  }

  const meta = {
    identifier: pack.shareId,
    name: pack.name,
    publisher: pack.artist,
    tray_image_file: pack.trayImage ? "tray.png" : "",
    stickers: stickerFiles,
  };
  entries.push({
    name: `${folder}/pack.json`,
    data: strBytes(JSON.stringify(meta, null, 2)),
  });

  return { blob: buildZip(entries), filename: `${folder}.zip` };
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
