import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { newId, newShareId } from "./ids";
import type { PackDetail, PackStatus, PackSummary, StickerRecord } from "./types";

type PackRow = {
  id: string;
  name: string;
  artist: string;
  tray_image: string | null;
  share_id: string;
  status: PackStatus;
  created_at: string;
  updated_at: string;
  sticker_count: number;
};

type StickerRow = {
  id: string;
  pack_id: string;
  image_webp: string;
  emojis: string;
  sort_order: number;
  byte_size: number;
  created_at: string;
};

function toSummary(row: PackRow): PackSummary {
  return {
    id: row.id,
    name: row.name,
    artist: row.artist,
    trayImage: row.tray_image,
    shareId: row.share_id,
    status: row.status,
    stickerCount: Number(row.sticker_count) || 0,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function toSticker(row: StickerRow): StickerRecord {
  return {
    id: row.id,
    packId: row.pack_id,
    imageWebp: row.image_webp,
    emojis: row.emojis,
    sortOrder: row.sort_order,
    byteSize: row.byte_size,
    createdAt: row.created_at,
  };
}

export const listPacks = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<PackRow>`
      select
        p.id, p.name, p.artist, p.tray_image, p.share_id, p.status,
        p.created_at, p.updated_at,
        coalesce((select count(*) from stickers s where s.pack_id = p.id), 0)::int as sticker_count
      from sticker_packs p
      where p.user_id = ${context.userId}
      order by p.updated_at desc
    `;
    return rows.map(toSummary);
  });

export const getPack = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data: id }) => {
    const sql = await getSql();
    const packs = await sql<PackRow>`
      select
        p.id, p.name, p.artist, p.tray_image, p.share_id, p.status,
        p.created_at, p.updated_at,
        coalesce((select count(*) from stickers s where s.pack_id = p.id), 0)::int as sticker_count
      from sticker_packs p
      where p.id = ${id} and p.user_id = ${context.userId}
      limit 1
    `;
    const pack = packs[0];
    if (!pack) return null;
    const stickers = await sql<StickerRow>`
      select id, pack_id, image_webp, emojis, sort_order, byte_size, created_at
      from stickers
      where pack_id = ${id} and user_id = ${context.userId}
      order by sort_order asc, created_at asc
    `;
    const detail: PackDetail = { ...toSummary(pack), stickers: stickers.map(toSticker) };
    return detail;
  });

export const getPublicPack = createServerFn({ method: "GET" })
  .validator((shareId: string) => shareId)
  .handler(async ({ data: shareId }) => {
    const sql = await getSql();
    const packs = await sql<PackRow>`
      select
        p.id, p.name, p.artist, p.tray_image, p.share_id, p.status,
        p.created_at, p.updated_at,
        coalesce((select count(*) from stickers s where s.pack_id = p.id), 0)::int as sticker_count
      from sticker_packs p
      where p.share_id = ${shareId} and p.status = 'saved'
      limit 1
    `;
    const pack = packs[0];
    if (!pack) return null;
    const stickers = await sql<StickerRow>`
      select id, pack_id, image_webp, emojis, sort_order, byte_size, created_at
      from stickers
      where pack_id = ${pack.id}
      order by sort_order asc, created_at asc
    `;
    const detail: PackDetail = { ...toSummary(pack), stickers: stickers.map(toSticker) };
    return detail;
  });

export const createPack = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { name: string; artist: string }) => {
    const name = input.name.trim().slice(0, 128);
    const artist = input.artist.trim().slice(0, 128);
    if (!name) throw new Error("Nama pack wajib diisi");
    if (!artist) throw new Error("Nama artis wajib diisi");
    return { name, artist };
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = newId("pack");
    const shareId = newShareId();
    await sql`
      insert into sticker_packs (id, user_id, name, artist, share_id, status)
      values (${id}, ${context.userId}, ${data.name}, ${data.artist}, ${shareId}, 'draft')
    `;
    return { id, shareId };
  });

export const updatePackMeta = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; name: string; artist: string; trayImage?: string | null }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const name = data.name.trim().slice(0, 128);
    const artist = data.artist.trim().slice(0, 128);
    if (!name || !artist) throw new Error("Nama pack dan artis wajib diisi");
    await sql`
      update sticker_packs
      set name = ${name},
          artist = ${artist},
          tray_image = ${data.trayImage ?? null},
          updated_at = now()
      where id = ${data.id} and user_id = ${context.userId}
    `;
    return { ok: true };
  });

export const savePackToProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data: id }) => {
    const sql = await getSql();
    const counts = await sql<{ n: number }>`
      select count(*)::int as n from stickers where pack_id = ${id} and user_id = ${context.userId}
    `;
    if ((counts[0]?.n ?? 0) < 1) throw new Error("Tambahkan stiker dulu sebelum menyimpan pack");
    await sql`
      update sticker_packs
      set status = 'saved', updated_at = now()
      where id = ${id} and user_id = ${context.userId}
    `;
    return { ok: true };
  });

export const deletePack = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data: id }) => {
    const sql = await getSql();
    await sql`delete from stickers where pack_id = ${id} and user_id = ${context.userId}`;
    await sql`delete from sticker_packs where id = ${id} and user_id = ${context.userId}`;
    return { ok: true };
  });

export const addStickers = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (input: {
      packId: string;
      stickers: Array<{ imageWebp: string; emojis?: string; byteSize: number }>;
    }) => input,
  )
  .handler(async ({ context, data }) => {
    if (data.stickers.length < 1) return { ids: [] as string[] };
    const sql = await getSql();
    const packs = await sql<{ id: string }>`
      select id from sticker_packs where id = ${data.packId} and user_id = ${context.userId} limit 1
    `;
    if (!packs[0]) throw new Error("Pack tidak ditemukan");

    const counts = await sql<{ n: number }>`
      select count(*)::int as n from stickers where pack_id = ${data.packId} and user_id = ${context.userId}
    `;
    const existing = counts[0]?.n ?? 0;
    if (existing + data.stickers.length > 30) {
      throw new Error("Maksimal 30 stiker per pack");
    }

    const ids: string[] = [];
    let order = existing;
    for (const sticker of data.stickers) {
      if (!sticker.imageWebp.startsWith("data:image/webp")) {
        throw new Error("Format stiker harus WebP");
      }
      if (sticker.imageWebp.length > 250_000) {
        throw new Error("Stiker terlalu besar");
      }
      const id = newId("stk");
      await sql`
        insert into stickers (id, pack_id, user_id, image_webp, emojis, sort_order, byte_size)
        values (
          ${id},
          ${data.packId},
          ${context.userId},
          ${sticker.imageWebp},
          ${sticker.emojis?.slice(0, 16) || "😀"},
          ${order},
          ${sticker.byteSize}
        )
      `;
      ids.push(id);
      order += 1;
    }

    const first = await sql<{ image_webp: string }>`
      select image_webp from stickers
      where pack_id = ${data.packId} and user_id = ${context.userId}
      order by sort_order asc
      limit 1
    `;
    if (first[0]) {
      await sql`
        update sticker_packs
        set tray_image = coalesce(tray_image, ${first[0].image_webp}),
            updated_at = now()
        where id = ${data.packId} and user_id = ${context.userId}
      `;
    }

    return { ids };
  });

export const deleteSticker = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { packId: string; stickerId: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      delete from stickers
      where id = ${data.stickerId} and pack_id = ${data.packId} and user_id = ${context.userId}
    `;
    await sql`
      update sticker_packs set updated_at = now()
      where id = ${data.packId} and user_id = ${context.userId}
    `;
    return { ok: true };
  });

export const importDraftPack = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (input: {
      name: string;
      artist: string;
      trayImage?: string | null;
      stickers: Array<{ imageWebp: string; emojis?: string; byteSize: number }>;
    }) => input,
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const name = data.name.trim().slice(0, 128);
    const artist = data.artist.trim().slice(0, 128);
    if (!name || !artist) throw new Error("Nama pack dan artis wajib diisi");
    const id = newId("pack");
    const shareId = newShareId();
    const status: PackStatus = data.stickers.length > 0 ? "saved" : "draft";
    await sql`
      insert into sticker_packs (id, user_id, name, artist, tray_image, share_id, status)
      values (${id}, ${context.userId}, ${name}, ${artist}, ${data.trayImage ?? null}, ${shareId}, ${status})
    `;
    let order = 0;
    for (const sticker of data.stickers.slice(0, 30)) {
      if (!sticker.imageWebp.startsWith("data:image/webp")) continue;
      const sid = newId("stk");
      await sql`
        insert into stickers (id, pack_id, user_id, image_webp, emojis, sort_order, byte_size)
        values (
          ${sid},
          ${id},
          ${context.userId},
          ${sticker.imageWebp},
          ${sticker.emojis?.slice(0, 16) || "😀"},
          ${order},
          ${sticker.byteSize}
        )
      `;
      order += 1;
    }
    return { id, shareId };
  });
