export function newId(prefix: string): string {
  const raw = crypto.randomUUID().replaceAll("-", "");
  return `${prefix}_${raw.slice(0, 16)}`;
}

export function newShareId(): string {
  return crypto.randomUUID().replaceAll("-", "").slice(0, 10);
}
