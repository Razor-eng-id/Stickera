import { create } from "zustand";
import { persist } from "zustand/middleware";
import { DRAFT_PACK_ID, type PackDetail, type StickerRecord } from "./types";

type DraftState = {
  pack: PackDetail | null;
  setMeta: (name: string, artist: string) => void;
  setPack: (pack: PackDetail) => void;
  addStickers: (stickers: StickerRecord[]) => void;
  removeSticker: (id: string) => void;
  updateSticker: (id: string, patch: Partial<StickerRecord>) => void;
  setTray: (trayImage: string | null) => void;
  clear: () => void;
};

function emptyPack(name: string, artist: string): PackDetail {
  const now = new Date().toISOString();
  return {
    id: DRAFT_PACK_ID,
    name,
    artist,
    trayImage: null,
    shareId: "draft",
    status: "draft",
    stickerCount: 0,
    createdAt: now,
    updatedAt: now,
    stickers: [],
  };
}

export const useDraftStore = create<DraftState>()(
  persist(
    (set, get) => ({
      pack: null,
      setMeta: (name, artist) => {
        const current = get().pack;
        set({
          pack: current
            ? { ...current, name, artist, updatedAt: new Date().toISOString() }
            : emptyPack(name, artist),
        });
      },
      setPack: (pack) => set({ pack }),
      addStickers: (stickers) => {
        const current = get().pack ?? emptyPack("Pack baru", "Artis");
        const next = [...current.stickers, ...stickers].map((s, i) => ({ ...s, sortOrder: i }));
        set({
          pack: {
            ...current,
            stickers: next,
            stickerCount: next.length,
            trayImage: current.trayImage ?? next[0]?.imageWebp ?? null,
            updatedAt: new Date().toISOString(),
          },
        });
      },
      removeSticker: (id) => {
        const current = get().pack;
        if (!current) return;
        const next = current.stickers.filter((s) => s.id !== id).map((s, i) => ({ ...s, sortOrder: i }));
        set({
          pack: {
            ...current,
            stickers: next,
            stickerCount: next.length,
            trayImage: next[0]?.imageWebp ?? null,
            updatedAt: new Date().toISOString(),
          },
        });
      },
      updateSticker: (id, patch) => {
        const current = get().pack;
        if (!current) return;
        set({
          pack: {
            ...current,
            stickers: current.stickers.map((s) => (s.id === id ? { ...s, ...patch } : s)),
            updatedAt: new Date().toISOString(),
          },
        });
      },
      setTray: (trayImage) => {
        const current = get().pack;
        if (!current) return;
        set({ pack: { ...current, trayImage, updatedAt: new Date().toISOString() } });
      },
      clear: () => set({ pack: null }),
    }),
    { name: "stikera-draft" },
  ),
);
