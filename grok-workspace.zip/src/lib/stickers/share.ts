import { dataUrlToBlob } from "./process";
import { downloadBlob, packToZip } from "./zip";
import type { PackDetail } from "./types";

export async function sharePackToDevice(pack: PackDetail): Promise<"shared" | "downloaded"> {
  const files: File[] = [];
  for (let i = 0; i < pack.stickers.length; i++) {
    const blob = dataUrlToBlob(pack.stickers[i].imageWebp);
    files.push(
      new File([blob], `${pack.name}-${String(i + 1).padStart(2, "0")}.webp`, {
        type: "image/webp",
      }),
    );
  }

  const payload = {
    files,
    title: pack.name,
    text: `${pack.name} oleh ${pack.artist}`,
  };

  if (typeof navigator !== "undefined" && typeof navigator.share === "function") {
    const can = typeof navigator.canShare === "function" ? navigator.canShare(payload) : true;
    if (can) {
      await navigator.share(payload);
      return "shared";
    }
  }

  const zip = await packToZip(pack);
  downloadBlob(zip.blob, zip.filename);
  return "downloaded";
}

export function shareLinkFor(shareId: string): string {
  if (typeof window === "undefined") return `/s/${shareId}`;
  return `${window.location.origin}/s/${shareId}`;
}
