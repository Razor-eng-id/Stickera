import {
  MAX_STICKER_BYTES,
  STICKER_SIZE,
  TRAY_SIZE,
  type ProcessOptions,
} from "./types";

export type ProcessedSticker = {
  dataUrl: string;
  bytes: number;
  wasGif: boolean;
};

function dataUrlBytes(dataUrl: string): number {
  const comma = dataUrl.indexOf(",");
  const b64 = comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl;
  return Math.floor((b64.length * 3) / 4);
}

function loadBitmap(file: File): Promise<ImageBitmap> {
  return createImageBitmap(file);
}

function dist(r1: number, g1: number, b1: number, r2: number, g2: number, b2: number): number {
  return Math.abs(r1 - r2) + Math.abs(g1 - g2) + Math.abs(b1 - b2);
}

function hasTransparency(data: Uint8ClampedArray): boolean {
  for (let i = 3; i < data.length; i += 4) {
    if (data[i] < 250) return true;
  }
  return false;
}

function floodClear(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  sx: number,
  sy: number,
  tr: number,
  tg: number,
  tb: number,
  threshold: number,
  visited: Uint8Array,
) {
  const stack = [sy * width + sx];
  while (stack.length) {
    const i = stack.pop()!;
    if (i < 0 || i >= width * height || visited[i]) continue;
    const p = i * 4;
    if (data[p + 3] === 0) {
      visited[i] = 1;
      continue;
    }
    if (dist(data[p], data[p + 1], data[p + 2], tr, tg, tb) > threshold) continue;
    visited[i] = 1;
    data[p + 3] = 0;
    const x = i % width;
    const y = (i / width) | 0;
    if (x > 0) stack.push(i - 1);
    if (x + 1 < width) stack.push(i + 1);
    if (y > 0) stack.push(i - width);
    if (y + 1 < height) stack.push(i + width);
  }
}

function removeBackground(image: ImageData): void {
  const { data, width, height } = image;
  if (hasTransparency(data)) return;

  const samples = [
    0,
    (width - 1) * 4,
    (height - 1) * width * 4,
    ((height - 1) * width + (width - 1)) * 4,
  ];
  let sr = 0;
  let sg = 0;
  let sb = 0;
  for (const i of samples) {
    sr += data[i];
    sg += data[i + 1];
    sb += data[i + 2];
  }
  sr = (sr / 4) | 0;
  sg = (sg / 4) | 0;
  sb = (sb / 4) | 0;

  const cornersClose =
    dist(data[0], data[1], data[2], sr, sg, sb) < 80 &&
    dist(data[(width - 1) * 4], data[(width - 1) * 4 + 1], data[(width - 1) * 4 + 2], sr, sg, sb) <
      80;

  const brightBg = sr > 220 && sg > 220 && sb > 220;
  if (!cornersClose && !brightBg) return;

  const visited = new Uint8Array(width * height);
  const starts: Array<[number, number]> = [
    [0, 0],
    [width - 1, 0],
    [0, height - 1],
    [width - 1, height - 1],
    [(width / 2) | 0, 0],
    [(width / 2) | 0, height - 1],
    [0, (height / 2) | 0],
    [width - 1, (height / 2) | 0],
  ];
  const threshold = brightBg ? 72 : 54;
  for (const [x, y] of starts) {
    floodClear(data, width, height, x, y, sr, sg, sb, threshold, visited);
  }

  // Soften the cut edge
  const copy = new Uint8ClampedArray(data);
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const i = (y * width + x) * 4;
      if (copy[i + 3] === 0) continue;
      let empty = 0;
      for (let oy = -1; oy <= 1; oy++) {
        for (let ox = -1; ox <= 1; ox++) {
          if (copy[((y + oy) * width + (x + ox)) * 4 + 3] === 0) empty++;
        }
      }
      if (empty >= 3) data[i + 3] = Math.max(0, data[i + 3] - empty * 18);
    }
  }
}

function addOutline(image: ImageData, radius: number): ImageData {
  const { width, height, data } = image;
  const out = new ImageData(width, height);
  const dest = out.data;
  dest.set(data);

  const opaque = new Uint8Array(width * height);
  for (let i = 0; i < width * height; i++) {
    opaque[i] = data[i * 4 + 3] > 24 ? 1 : 0;
  }

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = y * width + x;
      if (opaque[idx]) continue;
      let near = false;
      const y0 = Math.max(0, y - radius);
      const y1 = Math.min(height - 1, y + radius);
      const x0 = Math.max(0, x - radius);
      const x1 = Math.min(width - 1, x + radius);
      const r2 = radius * radius;
      for (let ny = y0; ny <= y1 && !near; ny++) {
        for (let nx = x0; nx <= x1; nx++) {
          const dx = nx - x;
          const dy = ny - y;
          if (dx * dx + dy * dy > r2) continue;
          if (opaque[ny * width + nx]) {
            near = true;
            break;
          }
        }
      }
      if (near) {
        const p = idx * 4;
        dest[p] = 255;
        dest[p + 1] = 255;
        dest[p + 2] = 255;
        dest[p + 3] = 255;
      }
    }
  }

  for (let i = 0; i < width * height; i++) {
    if (!opaque[i]) continue;
    const p = i * 4;
    dest[p] = data[p];
    dest[p + 1] = data[p + 1];
    dest[p + 2] = data[p + 2];
    dest[p + 3] = data[p + 3];
  }
  return out;
}

function drawFitted(
  ctx: CanvasRenderingContext2D,
  bitmap: ImageBitmap,
  size: number,
  fit: "contain" | "cover",
  padding: number,
) {
  const box = size - padding * 2;
  const bw = bitmap.width;
  const bh = bitmap.height;
  const scale = fit === "cover" ? Math.max(box / bw, box / bh) : Math.min(box / bw, box / bh);
  const dw = bw * scale;
  const dh = bh * scale;
  const dx = (size - dw) / 2;
  const dy = (size - dh) / 2;
  ctx.clearRect(0, 0, size, size);
  ctx.drawImage(bitmap, dx, dy, dw, dh);
}

async function canvasToWebp(canvas: HTMLCanvasElement, maxBytes: number): Promise<ProcessedSticker> {
  let quality = 0.84;
  let best = "";
  for (let i = 0; i < 8; i++) {
    const dataUrl = canvas.toDataURL("image/webp", quality);
    const bytes = dataUrlBytes(dataUrl);
    best = dataUrl;
    if (bytes <= maxBytes) {
      return { dataUrl, bytes, wasGif: false };
    }
    quality -= 0.08;
  }
  return { dataUrl: best, bytes: dataUrlBytes(best), wasGif: false };
}

export async function processSticker(file: File, options: ProcessOptions): Promise<ProcessedSticker> {
  if (!file.type.startsWith("image/")) {
    throw new Error("File bukan gambar");
  }
  const wasGif = file.type === "image/gif";
  const bitmap = await loadBitmap(file);
  const size = STICKER_SIZE;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas tidak tersedia");

  const pad = options.outline ? 18 : options.fit === "contain" ? 8 : 0;
  drawFitted(ctx, bitmap, size, options.fit, pad);
  bitmap.close();

  let image = ctx.getImageData(0, 0, size, size);
  if (options.removeBackground) removeBackground(image);
  if (options.outline) image = addOutline(image, 10);
  ctx.clearRect(0, 0, size, size);
  ctx.putImageData(image, 0, 0);

  const result = await canvasToWebp(canvas, MAX_STICKER_BYTES);
  result.wasGif = wasGif;
  return result;
}

export async function makeTrayIcon(stickerDataUrl: string): Promise<string> {
  const img = await loadImage(stickerDataUrl);
  const canvas = document.createElement("canvas");
  canvas.width = TRAY_SIZE;
  canvas.height = TRAY_SIZE;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas tidak tersedia");
  ctx.clearRect(0, 0, TRAY_SIZE, TRAY_SIZE);
  ctx.drawImage(img, 0, 0, TRAY_SIZE, TRAY_SIZE);
  return canvas.toDataURL("image/png");
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Gagal memuat gambar"));
    img.src = src;
  });
}

export function dataUrlToBlob(dataUrl: string): Blob {
  const [head, body] = dataUrl.split(",", 2);
  const mime = /data:([^;]+)/.exec(head)?.[1] ?? "application/octet-stream";
  const binary = atob(body ?? "");
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}
