export const MAX_STICKERS = 30;
export const MIN_PACK_STICKERS = 3;
export const STICKER_SIZE = 512;
export const TRAY_SIZE = 96;
export const MAX_STICKER_BYTES = 100 * 1024;
export const DRAFT_PACK_ID = "draft";

export type PackStatus = "draft" | "saved";

export type StickerRecord = {
  id: string;
  packId: string;
  imageWebp: string;
  emojis: string;
  sortOrder: number;
  byteSize: number;
  createdAt: string;
};

export type PackSummary = {
  id: string;
  name: string;
  artist: string;
  trayImage: string | null;
  shareId: string;
  status: PackStatus;
  stickerCount: number;
  createdAt: string;
  updatedAt: string;
};

export type PackDetail = PackSummary & {
  stickers: StickerRecord[];
};

export type ProcessOptions = {
  fit: "contain" | "cover";
  removeBackground: boolean;
  outline: boolean;
};

export const DEFAULT_PROCESS: ProcessOptions = {
  fit: "contain",
  removeBackground: true,
  outline: true,
};
