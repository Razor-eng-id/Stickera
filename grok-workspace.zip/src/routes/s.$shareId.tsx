import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { ChatPreview } from "@/components/stickers/chat-preview";
import { SendDialog } from "@/components/stickers/send-dialog";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { getPublicPack } from "@/lib/stickers/api";

export const Route = createFileRoute("/s/$shareId")({
  component: PublicPackPage,
});

function PublicPackPage() {
  const { shareId } = Route.useParams();
  const [sendOpen, setSendOpen] = useState(false);
  const query = useQuery({
    queryKey: ["public-pack", shareId],
    queryFn: () => getPublicPack({ data: shareId }),
  });

  return (
    <AppShell>
      <main className="mx-auto w-full max-w-3xl px-4 py-10">
        {query.isLoading ? (
          <Skeleton className="h-64 w-full rounded-xl" />
        ) : !query.data ? (
          <div className="text-center">
            <h1 className="font-display text-3xl">Pack tidak tersedia</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Pack ini belum disimpan ke profil, atau tautannya tidak valid.
            </p>
            <Button asChild className="mt-6">
              <Link to="/">Buat pack sendiri</Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-8">
            <div>
              <p className="text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase">
                Pack stiker
              </p>
              <h1 className="mt-1 font-display text-4xl font-medium tracking-tight">{query.data.name}</h1>
              <p className="mt-1 text-muted-foreground">oleh {query.data.artist}</p>
            </div>
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
              {query.data.stickers.map((s) => (
                <div key={s.id} className="sticker-checker aspect-square overflow-hidden rounded-lg bg-card shadow-(--shadow-border)">
                  <img src={s.imageWebp} alt="" className="size-full object-contain p-1" />
                </div>
              ))}
            </div>
            <ChatPreview pack={query.data} />
            <div className="flex flex-col gap-2 sm:flex-row">
              <Button type="button" onClick={() => setSendOpen(true)}>
                Kirim ke WhatsApp
              </Button>
              <Button asChild variant="outline">
                <Link to="/">Bikin pack sendiri</Link>
              </Button>
            </div>
            <SendDialog pack={query.data} open={sendOpen} onOpenChange={setSendOpen} />
          </div>
        )}
      </main>
    </AppShell>
  );
}
