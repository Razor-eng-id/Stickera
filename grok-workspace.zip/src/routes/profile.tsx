import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { AppShell } from "@/components/layout/app-shell";
import { PackCard } from "@/components/stickers/pack-card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { deletePack, listPacks } from "@/lib/stickers/api";

export const Route = createFileRoute("/profile")({
  component: ProfilePage,
});

function ProfilePage() {
  const { user, isPending } = useCurrentUserState();
  const queryClient = useQueryClient();
  const packs = useQuery({
    queryKey: ["packs"],
    queryFn: () => listPacks(),
    enabled: !!user,
  });
  const remove = useMutation({
    mutationFn: (id: string) => deletePack({ data: id }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["packs"] });
      toast.success("Pack dihapus");
    },
  });

  if (isPending) {
    return (
      <AppShell>
        <main className="mx-auto max-w-6xl px-4 py-10">
          <Skeleton className="h-16 w-64" />
        </main>
      </AppShell>
    );
  }

  if (!user) return <RedirectToSignIn />;

  const saved = packs.data?.filter((p) => p.status === "saved") ?? [];
  const drafts = packs.data?.filter((p) => p.status === "draft") ?? [];
  const stickerTotal = packs.data?.reduce((n, p) => n + p.stickerCount, 0) ?? 0;
  const label = user.displayName ?? user.primaryEmail ?? "Pengguna";

  return (
    <AppShell next="/profile">
      <main className="mx-auto w-full max-w-6xl px-4 py-8 sm:py-10">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
          <div className="grid size-16 place-items-center overflow-hidden rounded-full bg-secondary text-xl font-medium text-secondary-foreground">
            {user.profileImageUrl ? (
              <img src={user.profileImageUrl} alt="" className="size-full object-cover" />
            ) : (
              label.charAt(0).toUpperCase()
            )}
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="truncate font-display text-3xl font-medium tracking-tight">{label}</h1>
            <p className="truncate text-sm text-muted-foreground">{user.primaryEmail ?? "Profil Stikera"}</p>
          </div>
          <Button asChild>
            <Link to="/">Buka studio</Link>
          </Button>
        </div>

        <dl className="mt-8 grid grid-cols-3 gap-3">
          <Stat label="Pack tersimpan" value={saved.length} />
          <Stat label="Draf" value={drafts.length} />
          <Stat label="Stiker" value={stickerTotal} />
        </dl>

        <section className="mt-10">
          <h2 className="font-display text-2xl font-medium">Pack tersimpan</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Pack yang sudah kamu simpan ke profil. Buka untuk mengedit atau kirim ke WhatsApp.
          </p>
          {packs.isLoading ? (
            <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-3">
              <Skeleton className="aspect-[3/4] rounded-xl" />
              <Skeleton className="aspect-[3/4] rounded-xl" />
            </div>
          ) : saved.length === 0 ? (
            <div className="mt-5 rounded-xl bg-card px-5 py-10 text-center shadow-(--shadow-border)">
              <p className="text-sm text-muted-foreground">Belum ada pack tersimpan.</p>
              <Button asChild className="mt-4">
                <Link to="/">Buat pack</Link>
              </Button>
            </div>
          ) : (
            <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
              {saved.map((pack) => (
                <PackCard
                  key={pack.id}
                  pack={pack}
                  onDelete={(id) => {
                    if (confirm("Hapus pack ini?")) remove.mutate(id);
                  }}
                />
              ))}
            </div>
          )}
        </section>
      </main>
    </AppShell>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl bg-card px-4 py-4 shadow-(--shadow-border)">
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className="mt-1 font-display text-2xl font-medium tabular-nums">{value}</dd>
    </div>
  );
}
