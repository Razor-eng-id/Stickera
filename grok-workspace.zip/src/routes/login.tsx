import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Logo } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

type LoginSearch = { next?: string };

function safeNext(value: unknown): string {
  if (typeof value !== "string") return "/";
  if (!value.startsWith("/") || value.startsWith("//")) return "/";
  return value;
}

export const Route = createFileRoute("/login")({
  validateSearch: (search: Record<string, unknown>): LoginSearch => ({
    next: safeNext(search.next),
  }),
  component: LoginPage,
});

function GoogleGlyph() {
  return (
    <svg viewBox="0 0 24 24" className="size-4" aria-hidden="true">
      <path
        fill="#4285F4"
        d="M23.5 12.3c0-.85-.07-1.66-.21-2.44H12v4.62h6.46c-.28 1.5-1.12 2.77-2.4 3.62v3h3.88c2.27-2.09 3.56-5.17 3.56-8.8z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.24 0 5.96-1.07 7.95-2.9l-3.88-3c-1.08.74-2.46 1.18-4.07 1.18-3.13 0-5.78-2.11-6.73-4.96H1.27v3.09C3.25 21.3 7.31 24 12 24z"
      />
      <path
        fill="#FBBC05"
        d="M5.27 14.32A7.2 7.2 0 0 1 4.9 12c0-.81.14-1.59.37-2.32V6.59H1.27A12 12 0 0 0 0 12c0 1.94.46 3.77 1.27 5.41l4-3.09z"
      />
      <path
        fill="#EA4335"
        d="M12 4.75c1.76 0 3.34.6 4.58 1.79l3.44-3.44C17.95 1.19 15.24 0 12 0 7.31 0 3.25 2.7 1.27 6.59l4 3.09C6.22 6.86 8.87 4.75 12 4.75z"
      />
    </svg>
  );
}

function XGlyph() {
  return (
    <svg viewBox="0 0 24 24" className="size-4" aria-hidden="true">
      <path
        fill="currentColor"
        d="M18.2 2H21l-6.5 7.43L22 22h-6.8l-4.4-6.3L6 22H3.2l7-8.01L2 2h7l4 5.8L18.2 2Zm-1.2 18h1.9L7.1 3.9H5.1L17 20Z"
      />
    </svg>
  );
}

function LoginPage() {
  const { next = "/" } = Route.useSearch();
  const router = useRouter();
  const { user, isPending } = useCurrentUserState();
  const [oauthBusy, setOauthBusy] = useState<string | null>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [formBusy, setFormBusy] = useState(false);

  useEffect(() => {
    if (!isPending && user) router.history.push(next);
  }, [isPending, user, next, router]);

  async function onOauth(providerId: string) {
    setOauthBusy(providerId);
    try {
      await signIn(providerId, { callbackURL: next, errorCallbackURL: "/login" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal masuk");
      setOauthBusy(null);
    }
  }

  async function onEmailSignIn(e: React.FormEvent) {
    e.preventDefault();
    setFormBusy(true);
    try {
      const { error } = await authClient.signIn.email({ email, password });
      if (error) throw new Error(error.message ?? "Email atau kata sandi salah");
      await authClient.getSession();
      router.history.push(next);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal masuk");
    } finally {
      setFormBusy(false);
    }
  }

  async function onEmailSignUp(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 8) {
      toast.error("Kata sandi minimal 8 karakter");
      return;
    }
    setFormBusy(true);
    try {
      const { error } = await authClient.signUp.email({
        email,
        password,
        name: name.trim() || email.split("@")[0] || "Pengguna",
      });
      if (error) throw new Error(error.message ?? "Gagal membuat akun");
      await authClient.getSession();
      router.history.push(next);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal daftar");
    } finally {
      setFormBusy(false);
    }
  }

  return (
    <main className="paper-grid relative min-h-dvh px-4 py-10">
      <div className="mx-auto flex w-full max-w-md flex-col gap-8">
        <Link to="/" className="self-start">
          <Logo />
        </Link>
        <div className="rise-in rounded-xl bg-card p-6 shadow-(--shadow-lift) sm:p-8">
          <h1 className="font-display text-3xl font-medium tracking-tight">Masuk ke studio</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Profil menyimpan pack stiker kamu. Masuk dengan Google, X, atau daftar pakai email.
          </p>

          {authEnabled ? (
            <div className="mt-6 grid gap-2">
              {GROK_PROVIDERS.map((p) => (
                <Button
                  key={p.providerId}
                  type="button"
                  variant="outline"
                  className="h-12 justify-center"
                  disabled={oauthBusy !== null}
                  onClick={() => void onOauth(p.providerId)}
                >
                  {p.idp === "google" ? <GoogleGlyph /> : <XGlyph />}
                  {oauthBusy === p.providerId ? "Membuka…" : `Lanjut dengan ${p.label}`}
                </Button>
              ))}
            </div>
          ) : (
            <p className="mt-4 text-sm text-muted-foreground">Masuk sedang dinonaktifkan.</p>
          )}

          <div className="relative my-6">
            <div className="h-px bg-border" />
            <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-card px-3 text-xs text-muted-foreground">
              atau daftar dengan email
            </span>
          </div>

          <Tabs defaultValue="signup">
            <TabsList className="w-full">
              <TabsTrigger value="signup">Daftar</TabsTrigger>
              <TabsTrigger value="signin">Masuk</TabsTrigger>
            </TabsList>
            <TabsContent value="signup">
              <form onSubmit={onEmailSignUp} className="grid gap-3">
                <div className="grid gap-1.5">
                  <Label htmlFor="name">Nama</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Nama di profil"
                    autoComplete="name"
                  />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="email-up">Email</Label>
                  <Input
                    id="email-up"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    autoComplete="email"
                  />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="password-up">Kata sandi</Label>
                  <Input
                    id="password-up"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    minLength={8}
                    autoComplete="new-password"
                  />
                </div>
                <Button type="submit" disabled={formBusy || !authEnabled}>
                  {formBusy ? "Mendaftar…" : "Buat profil"}
                </Button>
              </form>
            </TabsContent>
            <TabsContent value="signin">
              <form onSubmit={onEmailSignIn} className="grid gap-3">
                <div className="grid gap-1.5">
                  <Label htmlFor="email-in">Email</Label>
                  <Input
                    id="email-in"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    autoComplete="email"
                  />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="password-in">Kata sandi</Label>
                  <Input
                    id="password-in"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    autoComplete="current-password"
                  />
                </div>
                <Button type="submit" disabled={formBusy || !authEnabled}>
                  {formBusy ? "Masuk…" : "Masuk dengan email"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </div>
        <p className="text-center text-xs text-muted-foreground">
          Dengan masuk, pack yang kamu simpan terikat ke profil ini.
        </p>
      </div>
    </main>
  );
}
