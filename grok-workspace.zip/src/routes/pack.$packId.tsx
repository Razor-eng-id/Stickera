import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link, Navigate, useNavigate } from "@tanstack/react-router";
import { Bookmark, Send } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/layout/app-shell";
import { ChatPreview } from "@/components/stickers/chat-preview";
import { SendDialog } from "@/components/stickers/send-dialog";
import { StickerEditor } from "@/components/stickers/sticker-editor";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import {
  addStickers,
  deleteSticker,
  getPack,
  importDraftPack,
  savePackToProfile,
  updatePackMeta,
} from "@/lib/stickers/api";
import { useDraftStore } from "@/lib/stickers/draft-store";
import { makeTrayIcon } from "@/lib/stickers/process";
import { DRAFT_PACK_ID, type PackDetail, type StickerRecord } from "@/lib/stickers/types";

export const Route = createFileRoute("/pack/$packId")({
  component: PackEditorPage,
});

function PackEditorPage() {
  const { packId } = Route.useParams();
  const isDraft = packId === DRAFT_PACK_ID;
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const draft = useDraftStore((s) => s.pack);
  const [sendOpen, setSendOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [name, setName] = useState("");
  const [artist, setArtist] = useState("");

  const query = useQuery({
    queryKey: ["pack", packId],
    queryFn: () => getPack({ data: packId }),
    enabled: !isDraft && !!user,
  });

  const pack: PackDetail | null = isDraft ? draft : (query.data ?? null);

  useEffect(() => {
    if (!pack) return;
    setName(pack.name);
    setArtist(pack.artist);
  }, [pack]);

  const localPack = useMemo(() => {
    if (!pack) return null;
    return { ...pack, name: name || pack.name, artist: artist || pack.artist };
  }, [pack, name, artist]);

  async function persistMeta(next: PackDetail) {
    if (isDraft) {
      useDraftStore.getState().setMeta(next.name, next.artist);
      if (next.trayImage) useDraftStore.getState().setTray(next.trayImage);
      return;
    }
    await updatePackMeta({
      data: {
        id: next.id,
        name: next.name,
        artist: next.artist,
        trayImage: next.trayImage,
      },
    });
    await queryClient.invalidateQueries({ queryKey: ["pack", packId] });
    await queryClient.invalidateQueries({ queryKey: ["packs"] });
  }

  async function onAdd(stickers: StickerRecord[]) {
    if (isDraft) {
      useDraftStore.getState().addStickers(stickers);
      const current = useDraftStore.getState().pack;
      if (current?.stickers[0] && !current.trayImage) {
        try {
          const tray = await makeTrayIcon(current.stickers[0].imageWebp);
          useDraftStore.getState().setTray(tray);
        } catch {
          /* ignore */
        }
      }
      return;
    }
    if (!user) {
      toast.error("Masuk dulu untuk menyimpan stiker");
      return;
    }
    for (const s of stickers) {
      await addStickers({
        data: {
          packId,
          stickers: [
            {
              imageWebp: s.imageWebp,
              emojis: s.emojis,
              byteSize: s.byteSize,
            },
          ],
        },
      });
    }
    await queryClient.invalidateQueries({ queryKey: ["pack", packId] });
    await queryClient.invalidateQueries({ queryKey: ["packs"] });
  }

  async function onRemove(id: string) {
    if (isDraft) {
      useDraftStore.getState().removeSticker(id);
      return;
    }
    await deleteSticker({ data: { packId, stickerId: id } });
    await queryClient.invalidateQueries({ queryKey: ["pack", packId] });
    await queryClient.invalidateQueries({ queryKey: ["packs"] });
  }

  async function onSaveProfile() {
    if (!localPack) return;
    if (localPack.stickers.length === 0) {
      toast.error("Unggah minimal satu stiker dulu");
      return;
    }
    if (!user) {
      useDraftStore.getState().setMeta(name, artist);
      await navigate({ to: "/login", search: { next: "/pack/draft" } });
      return;
    }
    setSaving(true);
    try {
      if (isDraft) {
        let tray = localPack.trayImage;
        if (!tray && localPack.stickers[0]) {
          tray = await makeTrayIcon(localPack.stickers[0].imageWebp);
        }
        const created = await importDraftPack({
          data: {
            name: name.trim() || localPack.name,
            artist: artist.trim() || localPack.artist,
            trayImage: tray,
            stickers: localPack.stickers.map((s) => ({
              imageWebp: s.imageWebp,
              emojis: s.emojis,
              byteSize: s.byteSize,
            })),
          },
        });
        useDraftStore.getState().clear();
        toast.success("Pack disimpan ke profil");
        await queryClient.invalidateQueries({ queryKey: ["packs"] });
        await navigate({ to: "/pack/$packId", params: { packId: created.id } });
        return;
      }
      await persistMeta({ ...localPack, name: name.trim(), artist: artist.trim() });
      await savePackToProfile({ data: packId });
      toast.success("Pack disimpan ke profil");
      await queryClient.invalidateQueries({ queryKey: ["pack", packId] });
      await queryClient.invalidateQueries({ queryKey: ["packs"] });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Gagal menyimpan";
      if (message === "Unauthorized") {
        await navigate({ to: "/login", search: { next: `/pack/${packId}` } });
        return;
      }
      toast.error(message);
    } finally {
      setSaving(false);
    }
  }

  if (!isDraft && !isPending && !user) {
    return <Navigate to="/login" search={{ next: `/pack/${packId}` }} />;
  }

  if (isPending && !isDraft) {
    return (
      <AppShell>
        <main className="mx-auto max-w-6xl px-4 py-10">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="mt-6 h-64 w-full rounded-xl" />
        </main>
      </AppShell>
    );
  }

  if (!isDraft && !query.isLoading && !pack) {
    return (
      <AppShell>
        <main className="mx-auto max-w-lg px-4 py-20 text-center">
          <h1 className="font-display text-3xl">Pack tidak ditemukan</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Pack ini bukan milik akun kamu, atau sudah dihapus.
          </p>
          <Button asChild className="mt-6">
            <Link to="/">Kembali ke studio</Link>
          </Button>
        </main>
      </AppShell>
    );
  }

  if (isDraft && !draft) {
    return (
      <AppShell>
        <main className="mx-auto max-w-lg px-4 py-20 text-center">
          <h1 className="font-display text-3xl">Belum ada draf</h1>
          <p className="mt-2 text-sm text-muted-foreground">Buat pack baru untuk mulai mengunggah stiker.</p>
          <Button asChild className="mt-6">
            <Link to="/">Buat pack</Link>
          </Button>
        </main>
      </AppShell>
    );
  }

  if (!localPack) {
    return (
      <AppShell>
        <main className="mx-auto max-w-6xl px-4 py-10">
          <Skeleton className="h-64 w-full rounded-xl" />
        </main>
      </AppShell>
    );
  }

  const saved = !isDraft && localPack.status === "saved";

  return (
    <AppShell
      next={`/pack/${packId}`}
      action={
        <div className="hidden items-center gap-2 sm:flex">
          <Button type="button" variant="outline" size="sm" onClick={() => setSendOpen(true)}>
            <Send className="size-4" />
            Kirim
          </Button>
          <Button type="button" size="sm" onClick={() => void onSaveProfile()} disabled={saving}>
            <Bookmark className="size-4" />
            {saving ? "Menyimpan…" : saved ? "Tersimpan" : "Simpan ke profil"}
          </Button>
        </div>
      }
    >
      <main className="mx-auto grid w-full max-w-6xl gap-8 px-4 py-6 pb-24 lg:grid-cols-[minmax(0,1fr)_280px] lg:py-8">
        <div>
          <p className="text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase">
            {isDraft ? "Draf lokal" : saved ? "Pack tersimpan" : "Draf"}
          </p>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label htmlFor="name">Nama pack</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                onBlur={() =>
                  void persistMeta({ ...localPack, name: name.trim() || localPack.name, artist })
                }
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="artist">Artis</Label>
              <Input
                id="artist"
                value={artist}
                onChange={(e) => setArtist(e.target.value)}
                onBlur={() =>
                  void persistMeta({ ...localPack, name, artist: artist.trim() || localPack.artist })
                }
              />
            </div>
          </div>
          <div className="mt-6">
            <StickerEditor pack={localPack} onAdd={onAdd} onRemove={onRemove} />
          </div>
        </div>
        <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
          <ChatPreview pack={localPack} />
          <p className="text-xs text-muted-foreground">
            WhatsApp butuh 3–30 stiker per pack. Stiker dibuat 512×512 WebP dengan latar transparan.
          </p>
        </aside>
      </main>

      <div className="sticky bottom-0 z-30 border-t border-border bg-background/95 px-4 py-3 backdrop-blur-sm sm:hidden">
        <div className="mx-auto flex max-w-6xl gap-2">
          <Button type="button" variant="outline" className="flex-1" onClick={() => setSendOpen(true)}>
            Kirim
          </Button>
          <Button type="button" className="flex-1" onClick={() => void onSaveProfile()} disabled={saving}>
            {saving ? "Menyimpan…" : "Simpan"}
          </Button>
        </div>
      </div>

      <SendDialog pack={localPack} open={sendOpen} onOpenChange={setSendOpen} />
    </AppShell>
  );
}
