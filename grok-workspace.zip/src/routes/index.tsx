import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ImagePlus, Plus, Share2, UserRound } from "lucide-react";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/layout/app-shell";
import { CreatePackDialog } from "@/components/stickers/create-pack-dialog";
import { PackCard } from "@/components/stickers/pack-card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { deletePack, listPacks } from "@/lib/stickers/api";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { user } = useCurrentUserState();
  const [open, setOpen] = useState(false);

  return (
    <AppShell
      action={
        <>
          <Button
            type="button"
            size="icon-sm"
            className="sm:hidden"
            onClick={() => setOpen(true)}
            aria-label="Pack baru"
          >
            <Plus className="size-4" />
          </Button>
          <Button type="button" size="sm" className="hidden sm:inline-flex" onClick={() => setOpen(true)}>
            Pack baru
          </Button>
        </>
      }
    >
      {user ? <Studio onCreate={() => setOpen(true)} /> : <Landing onCreate={() => setOpen(true)} />}
      <CreatePackDialog open={open} onOpenChange={setOpen} />
    </AppShell>
  );
}

function Studio({ onCreate }: { onCreate: () => void }) {
  const queryClient = useQueryClient();
  const packs = useQuery({ queryKey: ["packs"], queryFn: () => listPacks() });
  const remove = useMutation({
    mutationFn: (id: string) => deletePack({ data: id }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["packs"] });
      toast.success("Pack dihapus");
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : "Gagal menghapus"),
  });

  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-8 sm:py-10">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase">Studio</p>
          <h1 className="mt-1 font-display text-4xl font-medium tracking-tight">Pack kamu</h1>
          <p className="mt-2 max-w-xl text-sm text-muted-foreground">
            Buka pack untuk menambah stiker, simpan ke profil, lalu kirim ke WhatsApp.
          </p>
        </div>
        <Button asChild variant="outline">
          <Link to="/profile">Lihat profil</Link>
        </Button>
      </div>

      {packs.isLoading ? (
        <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
          <Skeleton className="aspect-[3/4] rounded-xl" />
          <Skeleton className="aspect-[3/4] rounded-xl" />
        </div>
      ) : packs.data && packs.data.length > 0 ? (
        <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
          {packs.data.map((pack) => (
            <PackCard
              key={pack.id}
              pack={pack}
              onDelete={(id) => {
                if (confirm("Hapus pack ini beserta stikernya?")) remove.mutate(id);
              }}
            />
          ))}
          <button
            type="button"
            onClick={onCreate}
            className="flex min-h-56 flex-col items-center justify-center gap-2 rounded-xl bg-card text-muted-foreground shadow-(--shadow-border) transition-[box-shadow] duration-150 hover:shadow-(--shadow-border-hover)"
          >
            <span className="grid size-12 place-items-center rounded-full bg-primary text-primary-foreground">
              <Plus className="size-6" />
            </span>
            <span className="text-sm">Pack baru</span>
          </button>
        </div>
      ) : (
        <div className="mt-10 rounded-xl bg-card px-6 py-14 text-center shadow-(--shadow-border)">
          <p className="font-display text-2xl">Studio masih kosong</p>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            Buat pack, tulis nama artis, lalu tekan plus untuk unggah gambar.
          </p>
          <Button type="button" className="mt-6" onClick={onCreate}>
            Buat pack pertama
          </Button>
        </div>
      )}
    </main>
  );
}

function Landing({ onCreate }: { onCreate: () => void }) {
  return (
    <main>
      <section className="paper-grid relative overflow-hidden">
        <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 py-12 lg:grid-cols-[1.1fr_0.9fr] lg:items-center lg:py-20">
          <div className="min-w-0">
            <p className="rise-in text-xs font-medium tracking-[0.18em] text-primary uppercase">
              Studio stiker WhatsApp
            </p>
            <h1 className="rise-in-2 mt-3 max-w-xl font-display text-4xl font-medium tracking-tight sm:text-6xl">
              Pack stiker, dari gambar biasa.
            </h1>
            <p className="rise-in-3 mt-4 max-w-lg text-base text-muted-foreground sm:text-lg">
              Tulis nama pack dan artisnya, unggah foto, Stikera merapikan jadi stiker 512×512 siap dikirim ke WhatsApp.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button type="button" size="lg" className="w-full sm:w-auto" onClick={onCreate}>
                Mulai pack baru
                <ArrowRight className="size-4" />
              </Button>
              <Button asChild size="lg" variant="outline" className="w-full sm:w-auto">
                <Link to="/login" search={{ next: "/" }}>
                  Masuk / daftar
                </Link>
              </Button>
            </div>
          </div>
          <StickerStage />
        </div>
      </section>

      <section className="mx-auto grid w-full max-w-6xl gap-3 px-4 py-12 sm:grid-cols-3">
        <Step
          icon={<ImagePlus className="size-5" />}
          n="01"
          title="Nama pack & artis"
          body="Setiap pack punya judul dan penerbit, seperti pack WhatsApp resmi."
        />
        <Step
          icon={<UserRound className="size-5" />}
          n="02"
          title="Unggah, rapikan"
          body="Tombol plus menerima banyak gambar. Latar dibersihkan, garis tepi ditambah."
        />
        <Step
          icon={<Share2 className="size-5" />}
          n="03"
          title="Simpan & kirim"
          body="Simpan ke profil, unduh ZIP, atau bagikan file WebP ke chat WhatsApp."
        />
      </section>
    </main>
  );
}

function Step({
  n,
  title,
  body,
  icon,
}: {
  n: string;
  title: string;
  body: string;
  icon: ReactNode;
}) {
  return (
    <article className="rounded-xl bg-card p-5 shadow-(--shadow-border)">
      <div className="flex items-center justify-between">
        <span className="grid size-10 place-items-center rounded-md bg-secondary text-secondary-foreground">
          {icon}
        </span>
        <span className="font-display text-sm text-muted-foreground">{n}</span>
      </div>
      <h2 className="mt-5 font-display text-xl font-medium">{title}</h2>
      <p className="mt-2 text-sm text-muted-foreground">{body}</p>
    </article>
  );
}

function StickerStage() {
  return (
    <div className="relative mx-auto hidden h-80 w-full max-w-md overflow-hidden sm:block sm:h-96 lg:block">
      <div className="absolute inset-8 rounded-[2rem] bg-card shadow-(--shadow-lift)" />
      <div className="sticker-checker rise-in absolute top-8 left-6 size-28 -rotate-6 rounded-2xl shadow-(--shadow-lift) sm:size-32">
        <svg viewBox="0 0 64 64" className="size-full p-4 text-primary" aria-hidden="true">
          <circle cx="32" cy="32" r="18" fill="currentColor" />
        </svg>
      </div>
      <div className="sticker-checker rise-in-2 absolute top-4 right-8 size-28 rotate-3 rounded-2xl shadow-(--shadow-lift) sm:size-32">
        <svg viewBox="0 0 64 64" className="size-full p-4 text-primary" aria-hidden="true">
          <path d="M32 12l6 14h14l-11 9 4 15-13-9-13 9 4-15-11-9h14z" fill="currentColor" />
        </svg>
      </div>
      <div className="sticker-checker rise-in-3 absolute bottom-10 left-16 size-28 -rotate-2 rounded-2xl shadow-(--shadow-lift) sm:size-32">
        <svg viewBox="0 0 64 64" className="size-full p-4 text-primary" aria-hidden="true">
          <path d="M32 14c8 8 18 12 18 24a18 18 0 1 1-36 0c0-12 10-16 18-24z" fill="currentColor" />
        </svg>
      </div>
      <div
        className="sticker-checker absolute right-10 bottom-8 size-28 rotate-6 rounded-2xl shadow-(--shadow-lift) sm:size-32"
        style={{ animation: "rise-in 400ms var(--ease-smooth-out) 200ms both" }}
      >
        <svg viewBox="0 0 64 64" className="size-full p-4 text-primary" aria-hidden="true">
          <rect x="16" y="16" width="32" height="32" rx="10" fill="currentColor" />
        </svg>
      </div>
    </div>
  );
}
